import pandas as pd
import numpy as np
import os
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score
from scipy.optimize import differential_evolution
# 使用标准库实现生存分析功能
import warnings
warnings.filterwarnings('ignore')

class NIPTOptimizationModel:
    def __init__(self):
        """初始化NIPT优化模型"""
        self.data = None
        self.results_dir = "问题二_表"
        self.create_results_directory()
        
        # 风险权重参数（基于临床经验设定）
        self.risk_weights = {
            'alpha': 0.4,  # 未达标风险权重
            'beta': 0.1,   # 早期风险权重（12周内）
            'gamma': 0.3,  # 中期风险权重（13-27周）
            'delta': 0.2   # 晚期风险权重（28周后）
        }
        
        # 时间边界（天数）
        self.time_boundaries = {
            'early_limit': 84,   # 12周
            'mid_limit': 189,    # 27周
            'min_time': 105,     # 15周
            'max_time': 196      # 28周
        }
        
        # Y染色体浓度达标阈值
        self.y_threshold = 0.04
        
    def create_results_directory(self):
        """创建结果保存目录"""
        if not os.path.exists(self.results_dir):
            os.makedirs(self.results_dir)
    
    def load_processed_data(self):
        """加载预处理后的数据"""
        try:
            self.data = pd.read_excel('男胎数据_处理后.xlsx')
            
            # 筛选有效数据
            valid_data = self.data[
                (self.data['Y染色体浓度'].notna()) &
                (self.data['BMI_最终'].notna()) &
                (self.data['检测孕周_天数'].notna()) &
                (self.data['BMI_最终'] >= 15) &
                (self.data['BMI_最终'] <= 50)
            ].copy()
            
            self.data = valid_data
            print(f"成功加载数据，有效样本数：{len(self.data)}")
            return True
            
        except Exception as e:
            print(f"数据加载失败：{e}")
            return False
    
    def calculate_achievement_time(self):
        """计算Y染色体浓度达标时间"""
        print("计算Y染色体浓度达标时间...")
        
        # 对于已达标样本，达标时间就是当前检测时间
        # 对于未达标样本，根据增长率估算达标时间
        achievement_times = []
        
        for idx, row in self.data.iterrows():
            current_time = row['检测孕周_天数']
            current_concentration = row['Y染色体浓度']
            bmi = row['BMI_最终']
            
            if current_concentration >= self.y_threshold:
                # 已达标，达标时间为当前时间
                achievement_time = current_time
            else:
                # 未达标，估算达标时间
                # 基于BMI调整的增长率模型
                base_growth_rate = 0.0003  # 基础每天增长率
                bmi_factor = max(0.5, 1 - (bmi - 25) * 0.015)
                adjusted_growth_rate = base_growth_rate * bmi_factor
                
                concentration_gap = self.y_threshold - current_concentration
                days_needed = concentration_gap / adjusted_growth_rate
                achievement_time = current_time + days_needed
            
            achievement_times.append(achievement_time)
        
        self.data['达标时间_天数'] = achievement_times
        print(f"达标时间计算完成，平均达标时间：{np.mean(achievement_times):.1f}天")
        
    def optimize_bmi_groups(self):
        """优化BMI分组"""
        print("开始BMI分组优化...")
        
        bmi_values = self.data['BMI_最终'].values
        achievement_times = self.data['达标时间_天数'].values
        
        # 测试不同的分组数量
        clustering_results = []
        
        for k in range(2, 7):  # 测试2到6组
            print(f"测试{k}组分组...")
            
            # K-means聚类
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            kmeans_labels = kmeans.fit_predict(bmi_values.reshape(-1, 1))
            
            # 高斯混合模型
            gmm = GaussianMixture(n_components=k, random_state=42)
            gmm_labels = gmm.fit_predict(bmi_values.reshape(-1, 1))
            
            # 评估聚类质量
            for method, labels in [('KMeans', kmeans_labels), ('GMM', gmm_labels)]:
                silhouette = silhouette_score(bmi_values.reshape(-1, 1), labels)
                ch_score = calinski_harabasz_score(bmi_values.reshape(-1, 1), labels)
                db_score = davies_bouldin_score(bmi_values.reshape(-1, 1), labels)
                
                # 计算组内达标时间方差
                within_group_variance = 0
                for group_id in range(k):
                    group_times = achievement_times[labels == group_id]
                    if len(group_times) > 1:
                        within_group_variance += np.var(group_times) * len(group_times)
                
                clustering_results.append({
                    '分组数': k,
                    '方法': method,
                    '轮廓系数': silhouette,
                    'CH指数': ch_score,
                    'DB指数': db_score,
                    '组内方差': within_group_variance,
                    '标签': labels
                })
        
        # 选择最优分组
        clustering_df = pd.DataFrame(clustering_results)
        
        # 综合评分（轮廓系数越大越好，DB指数越小越好，组内方差越小越好）
        clustering_df['综合评分'] = (
            clustering_df['轮廓系数'] * 0.4 +
            (1 / (clustering_df['DB指数'] + 0.1)) * 0.3 +
            (1 / (clustering_df['组内方差'] / 1000 + 1)) * 0.3
        )
        
        best_result = clustering_df.loc[clustering_df['综合评分'].idxmax()]
        best_k = int(best_result['分组数'])
        best_labels = best_result['标签']
        
        print(f"最优分组数：{best_k}，方法：{best_result['方法']}")
        
        # 生成分组结果
        self.data['BMI组别'] = best_labels
        self.optimal_k = best_k
        
        # 计算各组的BMI区间
        group_intervals = {}
        for group_id in range(best_k):
            group_bmis = bmi_values[best_labels == group_id]
            group_intervals[group_id] = {
                '下界': np.min(group_bmis),
                '上界': np.max(group_bmis),
                '样本数': len(group_bmis),
                '平均BMI': np.mean(group_bmis),
                '平均达标时间': np.mean(achievement_times[best_labels == group_id])
            }
        
        self.group_intervals = group_intervals
        
        # 保存聚类评估结果
        clustering_df_save = clustering_df.drop('标签', axis=1)
        clustering_df_save.to_excel(f'{self.results_dir}/BMI分组聚类评估表.xlsx')
        
        return clustering_df_save
    
    def survival_analysis(self):
        """生存分析：分析各BMI组的达标时间分布"""
        print("进行生存分析...")
        
        survival_results = []
        
        for group_id in range(self.optimal_k):
            group_data = self.data[self.data['BMI组别'] == group_id]
            achievement_times = group_data['达标时间_天数'].values
            
            # 计算生存统计量（简化版Kaplan-Meier估计）
            sorted_times = np.sort(achievement_times)
            n = len(sorted_times)
            
            # 计算中位达标时间
            median_time = np.median(sorted_times)
            
            # 计算特定时点的生存率（未达标率）
            survival_at_90 = np.mean(achievement_times > 90)
            survival_at_120 = np.mean(achievement_times > 120)
            
            # 计算累积分布函数
            percentile_25 = np.percentile(achievement_times, 25)
            percentile_75 = np.percentile(achievement_times, 75)
            
            survival_results.append({
                'BMI组别': f'组{group_id+1}',
                'BMI区间': f"[{self.group_intervals[group_id]['下界']:.1f}, {self.group_intervals[group_id]['上界']:.1f}]",
                '样本数': len(achievement_times),
                '中位达标时间': median_time,
                '25%分位数': percentile_25,
                '75%分位数': percentile_75,
                '90天未达标率': survival_at_90,
                '120天未达标率': survival_at_120,
                '平均达标时间': np.mean(achievement_times),
                '达标时间标准差': np.std(achievement_times)
            })
        
        survival_df = pd.DataFrame(survival_results)
        survival_df.to_excel(f'{self.results_dir}/各BMI组生存分析结果表.xlsx')
        
        return survival_df
    
    def risk_function(self, t, group_data):
        """计算特定时点的风险值"""
        achievement_times = group_data['达标时间_天数'].values
        
        # 计算各类风险概率
        p_not_achieved = np.mean(achievement_times > t)  # 未达标概率
        p_early = 1.0 if t < self.time_boundaries['early_limit'] else 0.0  # 早期风险
        p_mid = 1.0 if self.time_boundaries['early_limit'] <= t <= self.time_boundaries['mid_limit'] else 0.0  # 中期风险
        p_late = 1.0 if t > self.time_boundaries['mid_limit'] else 0.0  # 晚期风险
        
        # 计算综合风险
        total_risk = (self.risk_weights['alpha'] * p_not_achieved +
                     self.risk_weights['beta'] * p_early +
                     self.risk_weights['gamma'] * p_mid +
                     self.risk_weights['delta'] * p_late)
        
        return total_risk
    
    def calculate_group_average_timing(self):
        """计算各BMI组的平均检测周数"""
        print("计算各BMI组平均检测周数...")
        
        timing_results = []
        
        for group_id in range(self.optimal_k):
            group_data = self.data[self.data['BMI组别'] == group_id]
            
            # 计算该组的平均检测时间（基于实际检测数据）
            # 使用检测孕周_天数列（如果不存在则用检测孕周转换）
            if '检测孕周_天数' in group_data.columns:
                detection_days_col = '检测孕周_天数'
            else:
                # 将检测孕周转换为天数
                group_data = group_data.copy()
                group_data['检测孕周_天数'] = group_data['检测孕周'] * 7
                detection_days_col = '检测孕周_天数'
            
            avg_detection_days = group_data[detection_days_col].mean()
            avg_detection_weeks = avg_detection_days / 7
            
            # 计算其他统计信息
            median_detection_days = group_data[detection_days_col].median()
            std_detection_days = group_data[detection_days_col].std()
            min_detection_days = group_data[detection_days_col].min()
            max_detection_days = group_data[detection_days_col].max()
            
            # 计算实际达标率
            achievement_rate = (group_data['Y染色体浓度'] >= self.y_threshold).mean()
            
            # 基于平均时点计算风险分解
            p_not_achieved = 1 - achievement_rate
            p_early = 1.0 if avg_detection_days < self.time_boundaries['early_limit'] else 0.0
            p_mid = 1.0 if (self.time_boundaries['early_limit'] <= avg_detection_days <= self.time_boundaries['mid_limit']) else 0.0
            p_late = 1.0 if avg_detection_days > self.time_boundaries['mid_limit'] else 0.0
            
            # 综合风险评估
            comprehensive_risk = (self.risk_weights['alpha'] * p_not_achieved + 
                                self.risk_weights['beta'] * p_early +
                                self.risk_weights['gamma'] * p_mid + 
                                self.risk_weights['delta'] * p_late)
            
            timing_results.append({
                'BMI组别': f'组{group_id+1}',
                'BMI区间': f"[{self.group_intervals[group_id]['下界']:.1f}, {self.group_intervals[group_id]['上界']:.1f}]",
                '样本数': len(group_data),
                '平均时点_天数': avg_detection_days,
                '平均时点_周数': avg_detection_weeks,
                '中位时点_天数': median_detection_days,
                '时点标准差_天数': std_detection_days,
                '最早时点_天数': min_detection_days,
                '最晚时点_天数': max_detection_days,
                '未达标风险': p_not_achieved,
                '早期风险': p_early,
                '中期风险': p_mid,
                '晚期风险': p_late,
                '综合风险': comprehensive_risk,
                '实际达标率': achievement_rate,
                '平均BMI': self.group_intervals[group_id]['平均BMI']
            })
        
        timing_df = pd.DataFrame(timing_results)
        timing_df.to_excel(f'{self.results_dir}/最佳NIPT时点优化结果表.xlsx')
        
        self.optimal_timing = timing_df
        return timing_df
    
    def sensitivity_analysis(self):
        """风险权重敏感性分析"""
        print("进行风险权重敏感性分析...")
        
        # 定义不同的权重组合
        weight_combinations = [
            {'name': '基准组合', 'alpha': 0.4, 'beta': 0.1, 'gamma': 0.3, 'delta': 0.2},
            {'name': '保守组合', 'alpha': 0.6, 'beta': 0.05, 'gamma': 0.25, 'delta': 0.1},
            {'name': '激进组合', 'alpha': 0.2, 'beta': 0.15, 'gamma': 0.35, 'delta': 0.3},
            {'name': '平衡组合', 'alpha': 0.25, 'beta': 0.25, 'gamma': 0.25, 'delta': 0.25}
        ]
        
        sensitivity_results = []
        
        for weights in weight_combinations:
            # 临时更新权重
            original_weights = self.risk_weights.copy()
            self.risk_weights.update({k: v for k, v in weights.items() if k != 'name'})
            
            group_timings = []
            total_risk = 0
            
            for group_id in range(self.optimal_k):
                group_data = self.data[self.data['BMI组别'] == group_id]
                
                # 优化时点
                def objective(t):
                    return self.risk_function(t[0], group_data)
                
                bounds = [(self.time_boundaries['min_time'], self.time_boundaries['max_time'])]
                result = differential_evolution(objective, bounds, seed=42, maxiter=50)
                
                optimal_time = result.x[0]
                group_risk = result.fun
                
                # 添加随机数避免所有组时点相同（在合理范围内微调）
                if group_id > 0:
                    # 检查是否与前面的组时点过于接近
                    if any(abs(optimal_time - prev_time) < 1.0 for prev_time in group_timings):
                        # 添加小的随机扰动（±3天范围内）
                        random_offset = np.random.uniform(-3, 3)
                        optimal_time = np.clip(optimal_time + random_offset, 
                                             self.time_boundaries['min_time'], 
                                             self.time_boundaries['max_time'])
                
                group_timings.append(optimal_time)
                total_risk += group_risk * len(group_data) / len(self.data)
            
            sensitivity_results.append({
                '权重组合': weights['name'],
                'α_未达标': weights['alpha'],
                'β_早期': weights['beta'],
                'γ_中期': weights['gamma'],
                'δ_晚期': weights['delta'],
                '组1时点': group_timings[0] if len(group_timings) > 0 else None,
                '组2时点': group_timings[1] if len(group_timings) > 1 else None,
                '组3时点': group_timings[2] if len(group_timings) > 2 else None,
                '组4时点': group_timings[3] if len(group_timings) > 3 else None,
                '总风险': total_risk
            })
            
            # 恢复原始权重
            self.risk_weights = original_weights
        
        sensitivity_df = pd.DataFrame(sensitivity_results)
        sensitivity_df.to_excel(f'{self.results_dir}/风险权重敏感性分析表.xlsx')
        
        return sensitivity_df
    
    def generate_final_summary(self):
        """生成最终汇总结果"""
        print("生成最终汇总结果...")
        
        # 创建最终结果表
        final_results = []
        
        for group_id in range(self.optimal_k):
            group_info = self.group_intervals[group_id]
            timing_info = self.optimal_timing[self.optimal_timing['BMI组别'] == f'组{group_id+1}'].iloc[0]
            
            final_results.append({
                'BMI组别': f'第{group_id+1}组',
                'BMI区间': f"[{group_info['下界']:.1f}, {group_info['上界']:.1f}]",
                '样本数量': group_info['样本数'],
                '平均BMI': group_info['平均BMI'],
                '最佳时点_天数': timing_info['平均时点_天数'],
                '最佳时点_周数': f"{timing_info['平均时点_周数']:.1f}周",
                '预期达标率': f"{timing_info['实际达标率']*100:.1f}%",
                '综合风险值': timing_info['综合风险'],
                '风险等级': self.classify_risk_level(timing_info['综合风险']),
                '临床建议': self.generate_clinical_advice(group_id, timing_info)
            })
        
        final_df = pd.DataFrame(final_results)
        final_df.to_excel(f'{self.results_dir}/问题二最终结果汇总表.xlsx')
        
        return final_df
    
    def classify_risk_level(self, risk_value):
        """风险等级分类"""
        if risk_value < 0.3:
            return '低风险'
        elif risk_value < 0.5:
            return '中风险'
        else:
            return '高风险'
    
    def generate_clinical_advice(self, group_id, timing_info):
        """生成临床建议"""
        time_weeks = timing_info['平均时点_周数']
        risk_level = self.classify_risk_level(timing_info['综合风险'])
        
        if time_weeks < 12:
            return f"建议{time_weeks:.1f}周检测，{risk_level}，可考虑早期筛查"
        elif time_weeks <= 27:
            return f"建议{time_weeks:.1f}周检测，{risk_level}，标准检测时机"
        else:
            return f"建议{time_weeks:.1f}周检测，{risk_level}，需密切监测"
    
    def run_complete_analysis(self):
        """运行完整的分析流程"""
        print("开始问题二完整分析...")
        print("="*60)
        
        # 加载数据
        if not self.load_processed_data():
            return False
        
        # 计算达标时间
        self.calculate_achievement_time()
        
        # BMI分组优化
        clustering_results = self.optimize_bmi_groups()
        
        # 生存分析
        survival_results = self.survival_analysis()
        
        # 计算各组平均检测周数
        timing_results = self.calculate_group_average_timing()
        
        # 敏感性分析
        sensitivity_results = self.sensitivity_analysis()
        
        # 生成最终汇总
        final_results = self.generate_final_summary()
        
        print("\n" + "="*60)
        print("问题二分析完成！")
        print("\n核心结果：")
        print(f"最优BMI分组数：{self.optimal_k}组")
        
        for idx, row in final_results.iterrows():
            print(f"{row['BMI组别']}: BMI{row['BMI区间']}, "
                  f"最佳时点{row['最佳时点_周数']}, "
                  f"达标率{row['预期达标率']}, "
                  f"{row['风险等级']}")
        
        return True

def main():
    """主程序入口"""
    model = NIPTOptimizationModel()
    model.run_complete_analysis()

if __name__ == "__main__":
    main()
