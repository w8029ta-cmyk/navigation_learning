import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
import os
import warnings
warnings.filterwarnings('ignore')

class Problem2SCIPlotter:
    def __init__(self):
        """初始化绘图器"""
        self.results_dir = "问题二_图"
        self.data_dir = "问题二_表"
        self.create_output_directory()
        
        # 设置绘图参数
        self.sci_params = {
            'figure.dpi': 300,
            'savefig.dpi': 300,
            'font.size': 13,
            'axes.linewidth': 1.2,
            'axes.labelsize': 13,
            'axes.titlesize': 13,
            'xtick.labelsize': 13,
            'ytick.labelsize': 13,
            'legend.fontsize': 13,
            'figure.figsize': (8, 6),
            'axes.grid': True,
            'grid.alpha': 0.3,
            'grid.linestyle': '--',
            'axes.spines.top': False,
            'axes.spines.right': False
        }
        
        # 设置中文字体
        self.setup_chinese_font()

    def create_output_directory(self):
        """创建输出目录"""
        if not os.path.exists(self.results_dir):
            os.makedirs(self.results_dir)
    
    def setup_chinese_font(self):
        """设置中文字体"""
        font_paths = [
            'C:/Windows/Fonts/simhei.ttf',  # 黑体
            'C:/Windows/Fonts/msyh.ttc',   # 微软雅黑
            'C:/Windows/Fonts/simsun.ttc'  # 宋体
        ]
        
        self.font_prop = None
        for path in font_paths:
            if os.path.exists(path):
                self.font_prop = FontProperties(fname=path)
                plt.rcParams['font.family'] = self.font_prop.get_name()
                plt.rcParams['axes.unicode_minus'] = False
                break
        
        if self.font_prop is None:
            # 尝试系统字体
            try:
                plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
                plt.rcParams['axes.unicode_minus'] = False
                self.font_prop = FontProperties()
            except:
                print("警告：无法设置中文字体，可能显示为方块")
                self.font_prop = FontProperties()
        
        # 应用绘图参数
        plt.rcParams.update(self.sci_params)
    
    def load_data(self):
        """加载数据"""
        try:
            # 加载原始处理数据
            self.raw_data = pd.read_excel('男胎数据_处理后.xlsx')
            
            # 加载NSGA-II结果
            self.pareto_solutions = pd.read_excel(f'{self.data_dir}/NSGA2帕累托最优解汇总.xlsx')
            self.detailed_results = pd.read_excel(f'{self.data_dir}/NSGA2详细分组结果.xlsx')
            self.evolution_history = pd.read_excel(f'{self.data_dir}/NSGA2进化历史.xlsx')
            
            # 加载其他结果
            self.clustering_results = pd.read_excel(f'{self.data_dir}/BMI分组聚类评估表.xlsx')
            self.timing_results = pd.read_excel(f'{self.data_dir}/最佳NIPT时点优化结果表.xlsx')
            
            print("数据加载完成")
            return True
            
        except Exception as e:
            print(f"数据加载失败: {e}")
            return False
    
    def plot_hexbin_bmi_concentration(self):
        """BMI与Y染色体浓度关系蜂窝图"""
        plt.figure(figsize=(8, 6))
        
        # 过滤有效数据
        valid_data = self.raw_data[(self.raw_data['BMI_最终'].notna()) & 
                                  (self.raw_data['Y染色体浓度'].notna())]
        
        x = valid_data['BMI_最终']
        y = valid_data['Y染色体浓度']
        
        # 创建蜂窝图
        hb = plt.hexbin(x, y, gridsize=25, cmap='magma', alpha=0.8)
        
        # 添加颜色条
        cb = plt.colorbar(hb)
        cb.set_label('样本密度', fontproperties=self.font_prop)
        
        # 添加4%阈值线
        plt.axhline(y=0.04, color=np.random.rand(3, ), linestyle='--', linewidth=2, alpha=0.8, label='4%阈值线')
        
        plt.xlabel('孕妇BMI', fontproperties=self.font_prop)
        plt.ylabel('Y染色体浓度', fontproperties=self.font_prop)
        plt.title('BMI与Y染色体浓度关系蜂窝图', fontproperties=self.font_prop)
        plt.legend(prop=self.font_prop)
        
        plt.tight_layout()
        plt.savefig(f'{self.results_dir}/BMI与Y染色体浓度蜂窝图.png',
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_evolution_history(self):
        """NSGA-II算法进化历史"""
        plt.figure(figsize=(8, 6))
        
        generations = self.evolution_history['代数']
        colors = [np.random.rand(3, ) for _ in range(3)]
        labels = ['平均风险', '平均方差', '平均不平衡']
        
        # 标准化数据以便比较
        for i, (col, color, label) in enumerate(zip(['平均风险', '平均方差', '平均不平衡'], colors, labels)):
            values = self.evolution_history[col]
            normalized_values = (values - values.min()) / (values.max() - values.min())
            plt.plot(generations, normalized_values, color=color, linewidth=2, 
                    label=label, marker='o', markersize=4, alpha=0.8)
        
        plt.xlabel('进化代数', fontproperties=self.font_prop)
        plt.ylabel('标准化目标函数值', fontproperties=self.font_prop)
        plt.title('NSGA-II算法进化过程', fontproperties=self.font_prop)
        plt.legend(prop=self.font_prop)
        
        plt.tight_layout()
        plt.savefig(f'{self.results_dir}/NSGA2算法进化历史.png',
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_bmi_groups_analysis(self):
        """最优BMI分组分析箱线图"""
        plt.figure(figsize=(8, 6))

        # 准备数据
        plot_data = []
        group_labels = []

        for _, row in self.detailed_results.iterrows():
            if row['解编号'] == 1:  # 使用第一个解的分组
                bmi_range = row['BMI区间']
                group_name = row['组别']

                # 解析BMI区间
                bmi_range_clean = bmi_range.strip('[]').split(', ')
                bmi_min = float(bmi_range_clean[0])
                bmi_max = float(bmi_range_clean[1])

                # 筛选该组数据
                mask = (self.raw_data['BMI_最终'] >= bmi_min) & (self.raw_data['BMI_最终'] <= bmi_max)
                group_data = self.raw_data[mask]['Y染色体浓度'].dropna()

                plot_data.append(group_data)
                group_labels.append(f"{group_name}\n{bmi_range}")

        # 创建箱线图
        box_plot = plt.boxplot(plot_data, labels=group_labels, patch_artist=True)

        # 设置颜色
        colors = [np.random.rand(3, ) for _ in range(len(plot_data))]
        for patch, color in zip(box_plot['boxes'], colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)

        # 添加4%阈值线
        plt.axhline(y=0.04, color='red', linestyle='--', linewidth=2, alpha=0.8, label='4%阈值线')

        plt.xlabel('BMI组别', fontproperties=self.font_prop)
        plt.ylabel('Y染色体浓度', fontproperties=self.font_prop)
        plt.title('最优BMI分组Y染色体浓度分布', fontproperties=self.font_prop)
        plt.legend(prop=self.font_prop)
        plt.xticks(rotation=45)

        plt.tight_layout()
        plt.savefig(f'{self.results_dir}/最优BMI分组分析.png',
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_detection_timing_optimization(self):
        """检测时点优化结果"""
        plt.figure(figsize=(8, 6))
        
        # 使用第一个解的数据
        solution_1_data = self.detailed_results[self.detailed_results['解编号'] == 1]
        
        groups = solution_1_data['组别']
        detection_weeks = solution_1_data['检测时点_周'].str.replace('周', '').astype(float)
        achievement_rates = solution_1_data['达标率'].str.replace('%', '').astype(float)
        sample_sizes = solution_1_data['样本数']
        
        # 创建双轴图
        fig, ax1 = plt.subplots(figsize=(8, 6))
        
        # 左轴：检测时点
        bars1 = ax1.bar([i-0.1 for i in range(len(groups))], detection_weeks,
                       width=0.2, color=np.random.rand(3, ),
                       alpha=0.8, label='最佳检测时点')
        ax1.set_xlabel('BMI组别', fontproperties=self.font_prop)
        ax1.set_ylabel('检测时点（周）', fontproperties=self.font_prop, color=np.random.rand(3, ))
        ax1.tick_params(axis='y', labelcolor=np.random.rand(3, ))
        ax1.set_ylim(0, 15)
        # 右轴：达标率
        ax2 = ax1.twinx()
        bars2 = ax2.bar([i+0.1 for i in range(len(groups))], achievement_rates,
                       width=0.2, color = np.random.rand(3, ),
                       alpha=0.8, label='预期达标率')
        ax2.set_ylabel('达标率（%）', fontproperties=self.font_prop, color=np.random.rand(3, ))
        ax2.tick_params(axis='y', labelcolor=np.random.rand(3, ))
        ax2.set_ylim(0, 120)
        # 设置x轴标签
        ax1.set_xticks(range(len(groups)))
        ax1.set_xticklabels(groups)
        
        # 添加数值标签
        for i, (week, rate) in enumerate(zip(detection_weeks, achievement_rates)):
            ax1.text(i-0.1, week+0.2, f'{week:.1f}', ha='center', va='bottom', fontsize=10)
            ax2.text(i+0.1, rate+1, f'{rate:.1f}%', ha='center', va='bottom', fontsize=10)
        
        plt.title('各BMI组最佳检测时点与预期达标率', fontproperties=self.font_prop)
        
        # 合并图例
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, prop=self.font_prop, loc='upper right')
        
        plt.tight_layout()
        plt.savefig(f'{self.results_dir}/检测时点优化结果.png',
                   dpi=300, bbox_inches='tight')
        plt.close()

    
    def run_all_plots(self):
        """运行所有绘图"""
        print("开始生成图...")
        
        if not self.load_data():
            return False

        print("问题二SCI风格图表生成完成！")
        return True

def main():
    """主程序入口"""
    plotter = Problem2SCIPlotter()
    plotter.run_all_plots()

if __name__ == "__main__":
    main()
