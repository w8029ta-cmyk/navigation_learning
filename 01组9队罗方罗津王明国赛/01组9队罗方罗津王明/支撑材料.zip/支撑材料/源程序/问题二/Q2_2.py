import pandas as pd
import numpy as np
import os
import random
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

class RobustNSGA2Model:
    def __init__(self):
        """初始化鲁棒NSGA-II规划模型"""
        self.data = None
        self.results_dir = "问题二_表"
        self.create_results_directory()
        
        # NSGA-II算法参数
        self.population_size = 50
        self.generations = 100
        self.crossover_rate = 0.8
        self.mutation_rate = 0.2
        self.tournament_size = 3
        
        # 问题参数
        self.min_groups = 4
        self.max_groups = 8
        self.y_threshold = 0.04
        self.time_bounds = (105, 196)  # 检测时点范围（天）15-28周
        
        # 不确定性参数
        self.uncertainty_level = 0.1  # 不确定性水平
        self.monte_carlo_samples = 20  # 蒙特卡洛采样数
        
        # 风险权重
        self.base_weights = {'alpha': 0.4, 'beta': 0.1, 'gamma': 0.3, 'delta': 0.2}
        
    def create_results_directory(self):
        """创建结果保存目录"""
        if not os.path.exists(self.results_dir):
            os.makedirs(self.results_dir)
    
    def load_processed_data(self):
        """加载预处理后的数据"""
        try:
            self.data = pd.read_excel('男胎数据_处理后.xlsx')
            
            # 筛选有效数据
            valid_data = self.data[
                (self.data['Y染色体浓度'].notna()) &
                (self.data['BMI_最终'].notna()) &
                (self.data['检测孕周_天数'].notna()) &
                (self.data['BMI_最终'] >= 15) &
                (self.data['BMI_最终'] <= 50)
            ].copy()
            
            self.data = valid_data
            self.bmi_values = self.data['BMI_最终'].values
            self.y_concentrations = self.data['Y染色体浓度'].values
            self.detection_times = self.data['检测孕周_天数'].values
            
            # 计算达标时间
            self.calculate_achievement_times()
            
            print(f"成功加载数据，有效样本数：{len(self.data)}")
            return True
            
        except Exception as e:
            print(f"数据加载失败：{e}")
            return False
    
    def calculate_achievement_times(self):
        """计算Y染色体浓度达标时间"""
        achievement_times = []
        
        for i in range(len(self.data)):
            current_time = self.detection_times[i]
            current_concentration = self.y_concentrations[i]
            bmi = self.bmi_values[i]
            
            if current_concentration >= self.y_threshold:
                achievement_time = current_time
            else:
                # 基于BMI的增长率模型
                base_growth_rate = 0.0003
                bmi_factor = max(0.5, 1 - (bmi - 25) * 0.015)
                adjusted_growth_rate = base_growth_rate * bmi_factor
                
                concentration_gap = self.y_threshold - current_concentration
                days_needed = concentration_gap / adjusted_growth_rate
                achievement_time = current_time + days_needed
            
            achievement_times.append(achievement_time)
        
        self.achievement_times = np.array(achievement_times)
    
    def generate_uncertainty_scenarios(self):
        """生成不确定性场景"""
        n_samples = len(self.data)
        scenarios = []
        
        for _ in range(self.monte_carlo_samples):
            # BMI测量误差
            bmi_noise = np.random.normal(0, self.uncertainty_level * np.std(self.bmi_values), n_samples)
            bmi_perturbed = self.bmi_values + bmi_noise
            
            # Y染色体浓度测量误差
            y_noise = np.random.normal(0, self.uncertainty_level * np.std(self.y_concentrations), n_samples)
            y_perturbed = np.maximum(0, self.y_concentrations + y_noise)
            
            # 时间测量误差
            time_noise = np.random.normal(0, self.uncertainty_level * np.std(self.detection_times), n_samples)
            time_perturbed = np.maximum(105, np.minimum(196, self.detection_times + time_noise))
            
            scenarios.append({
                'bmi': bmi_perturbed,
                'y_concentration': y_perturbed,
                'detection_time': time_perturbed
            })
        
        return scenarios
    
    class Individual:
        """个体类：表示一个解决方案"""
        def __init__(self, n_groups, n_samples):
            self.n_groups = n_groups
            self.n_samples = n_samples
            
            # 决策变量：BMI分组边界和检测时点
            self.bmi_boundaries = sorted(np.random.uniform(20, 45, max(1, n_groups-1)))
            
            # 生成检测时点，确保各组时点有差异
            self.detection_times = np.random.uniform(105, 196, n_groups)
            # 添加小的随机偏移确保时点不完全相同
            for i in range(1, n_groups):
                while any(abs(self.detection_times[i] - self.detection_times[j]) < 2.0 for j in range(i)):
                    self.detection_times[i] = np.random.uniform(105, 196)
                    # 添加小的随机扰动
                    self.detection_times[i] += np.random.uniform(-3, 3)
                    self.detection_times[i] = np.clip(self.detection_times[i], 105, 196)
            
            # 目标函数值
            self.objectives = None
            self.rank = None
            self.crowding_distance = 0
            self.dominated_solutions = []
            self.domination_count = 0
        
        def assign_groups(self, bmi_values):
            """根据BMI边界分配样本到组"""
            groups = np.zeros(len(bmi_values), dtype=int)
            
            # 确保边界数量正确
            if len(self.bmi_boundaries) != self.n_groups - 1:
                # 重新生成边界
                sorted_bmis = np.sort(bmi_values)
                percentiles = np.linspace(0, 100, self.n_groups + 1)[1:-1]
                self.bmi_boundaries = sorted(np.percentile(sorted_bmis, percentiles))
            
            for i, bmi in enumerate(bmi_values):
                group = 0
                for boundary in self.bmi_boundaries:
                    if bmi <= boundary:
                        break
                    group += 1
                groups[i] = min(group, self.n_groups - 1)
            
            return groups
        
        def dominates(self, other):
            """判断是否支配另一个解"""
            if self.objectives is None or other.objectives is None:
                return False
            
            better_in_all = all(a <= b for a, b in zip(self.objectives, other.objectives))
            better_in_at_least_one = any(a < b for a, b in zip(self.objectives, other.objectives))
            
            return better_in_all and better_in_at_least_one
    
    def evaluate_individual(self, individual, scenarios):
        """评估个体的目标函数值"""
        total_risk = 0
        total_variance = 0
        total_unfairness = 0
        
        # 在所有不确定性场景下评估
        for scenario in scenarios:
            groups = individual.assign_groups(scenario['bmi'])
            
            scenario_risk = 0
            scenario_variance = 0
            group_sizes = []
            
            for group_id in range(individual.n_groups):
                group_mask = (groups == group_id)
                if not np.any(group_mask):
                    continue
                
                group_sizes.append(np.sum(group_mask))
                group_achievement_times = self.achievement_times[group_mask]
                
                # 确保检测时点数组长度匹配
                if group_id < len(individual.detection_times):
                    detection_time = individual.detection_times[group_id]
                else:
                    detection_time = individual.detection_times[-1]  # 使用最后一个时点
                
                # 计算风险
                p_not_achieved = np.mean(group_achievement_times > detection_time)
                p_early = 1.0 if detection_time < 84 else 0.0
                p_mid = 1.0 if 84 <= detection_time <= 189 else 0.0
                p_late = 1.0 if detection_time > 189 else 0.0
                
                risk = (self.base_weights['alpha'] * p_not_achieved +
                       self.base_weights['beta'] * p_early +
                       self.base_weights['gamma'] * p_mid +
                       self.base_weights['delta'] * p_late)
                
                scenario_risk += risk * np.sum(group_mask) / len(scenario['bmi'])
                scenario_variance += np.var(group_achievement_times)
            
            # 计算组间平衡性（不公平性）
            if len(group_sizes) > 1:
                scenario_unfairness = np.std(group_sizes) / np.mean(group_sizes)
            else:
                scenario_unfairness = 0
            
            total_risk += scenario_risk
            total_variance += scenario_variance
            total_unfairness += scenario_unfairness
        
        # 平均化
        avg_risk = total_risk / len(scenarios)
        avg_variance = total_variance / len(scenarios)
        avg_unfairness = total_unfairness / len(scenarios)
        
        # 三个目标：最小化风险、最小化方差、最小化不公平性
        individual.objectives = [avg_risk, avg_variance, avg_unfairness]
        
        return individual.objectives
    
    def tournament_selection(self, population):
        """锦标赛选择"""
        tournament = random.sample(population, self.tournament_size)
        
        # 选择最优个体（基于支配关系和拥挤距离）
        best = tournament[0]
        for individual in tournament[1:]:
            # 处理rank为None的情况
            if best.rank is None:
                best.rank = float('inf')
            if individual.rank is None:
                individual.rank = float('inf')
                
            if (individual.rank < best.rank or 
                (individual.rank == best.rank and individual.crowding_distance > best.crowding_distance)):
                best = individual
        
        return best
    
    def crossover(self, parent1, parent2):
        """交叉操作"""
        if random.random() > self.crossover_rate:
            return parent1, parent2
        
        # 选择相同分组数的父代进行交叉
        if parent1.n_groups != parent2.n_groups:
            return parent1, parent2
        
        child1 = self.Individual(parent1.n_groups, parent1.n_samples)
        child2 = self.Individual(parent2.n_groups, parent2.n_samples)
        
        # BMI边界交叉
        if len(parent1.bmi_boundaries) == len(parent2.bmi_boundaries) and len(parent1.bmi_boundaries) > 0:
            crossover_point = random.randint(0, len(parent1.bmi_boundaries))
            child1.bmi_boundaries = sorted(parent1.bmi_boundaries[:crossover_point] + 
                                         parent2.bmi_boundaries[crossover_point:])
            child2.bmi_boundaries = sorted(parent2.bmi_boundaries[:crossover_point] + 
                                         parent1.bmi_boundaries[crossover_point:])
        else:
            child1.bmi_boundaries = parent1.bmi_boundaries.copy()
            child2.bmi_boundaries = parent2.bmi_boundaries.copy()
        
        # 检测时点交叉
        if len(parent1.detection_times) == len(parent2.detection_times):
            crossover_point = random.randint(0, len(parent1.detection_times))
            child1.detection_times = np.concatenate([
                parent1.detection_times[:crossover_point],
                parent2.detection_times[crossover_point:]
            ])
            child2.detection_times = np.concatenate([
                parent2.detection_times[:crossover_point],
                parent1.detection_times[crossover_point:]
            ])
        else:
            child1.detection_times = parent1.detection_times.copy()
            child2.detection_times = parent2.detection_times.copy()
        
        return child1, child2
    
    def mutate(self, individual):
        """变异操作"""
        if random.random() > self.mutation_rate:
            return individual
        
        # BMI边界变异
        if individual.bmi_boundaries and random.random() < 0.5:
            idx = random.randint(0, len(individual.bmi_boundaries) - 1)
            individual.bmi_boundaries[idx] += random.gauss(0, 2)
            individual.bmi_boundaries[idx] = max(20, min(45, individual.bmi_boundaries[idx]))
            individual.bmi_boundaries = sorted(individual.bmi_boundaries)
        
        # 检测时点变异
        if random.random() < 0.5:
            idx = random.randint(0, len(individual.detection_times) - 1)
            original_time = individual.detection_times[idx]
            individual.detection_times[idx] += random.gauss(0, 10)
            individual.detection_times[idx] = max(105, min(196, individual.detection_times[idx]))
            
            # 检查是否与其他时点过于接近，如果是则添加随机扰动
            other_times = [individual.detection_times[j] for j in range(len(individual.detection_times)) if j != idx]
            if any(abs(individual.detection_times[idx] - other_time) < 1.0 for other_time in other_times):
                individual.detection_times[idx] = original_time + random.uniform(-5, 5)
                individual.detection_times[idx] = max(105, min(196, individual.detection_times[idx]))
        
        return individual
    
    def fast_non_dominated_sort(self, population):
        """快速非支配排序"""
        fronts = [[]]
        
        for individual in population:
            individual.dominated_solutions = []
            individual.domination_count = 0
            
            for other in population:
                if individual.dominates(other):
                    individual.dominated_solutions.append(other)
                elif other.dominates(individual):
                    individual.domination_count += 1
            
            if individual.domination_count == 0:
                individual.rank = 0
                fronts[0].append(individual)
        
        i = 0
        while len(fronts[i]) > 0:
            next_front = []
            for individual in fronts[i]:
                for dominated in individual.dominated_solutions:
                    dominated.domination_count -= 1
                    if dominated.domination_count == 0:
                        dominated.rank = i + 1
                        next_front.append(dominated)
            i += 1
            fronts.append(next_front)
        
        return fronts[:-1]  # 移除最后一个空前沿
    
    def calculate_crowding_distance(self, front):
        """计算拥挤距离"""
        if len(front) <= 2:
            for individual in front:
                individual.crowding_distance = float('inf')
            return
        
        for individual in front:
            individual.crowding_distance = 0
        
        n_objectives = len(front[0].objectives)
        
        for obj_idx in range(n_objectives):
            front.sort(key=lambda x: x.objectives[obj_idx])
            
            front[0].crowding_distance = float('inf')
            front[-1].crowding_distance = float('inf')
            
            obj_range = front[-1].objectives[obj_idx] - front[0].objectives[obj_idx]
            if obj_range == 0:
                continue
            
            for i in range(1, len(front) - 1):
                distance = (front[i+1].objectives[obj_idx] - front[i-1].objectives[obj_idx]) / obj_range
                front[i].crowding_distance += distance
    
    def nsga2_main_loop(self):
        """NSGA-II主循环"""
        print("开始NSGA-II优化...")
        
        # 生成不确定性场景
        scenarios = self.generate_uncertainty_scenarios()
        
        # 初始化种群
        population = []
        for _ in range(self.population_size):
            n_groups = random.randint(self.min_groups, self.max_groups)
            individual = self.Individual(n_groups, len(self.data))
            self.evaluate_individual(individual, scenarios)
            population.append(individual)
        
        # 对初始种群进行非支配排序
        fronts = self.fast_non_dominated_sort(population)
        for front in fronts:
            self.calculate_crowding_distance(front)
        
        # 记录进化过程
        evolution_history = []
        
        for generation in range(self.generations):
            if generation % 20 == 0:
                print(f"第{generation}代...")
            
            # 生成子代
            offspring = []
            for _ in range(self.population_size // 2):
                parent1 = self.tournament_selection(population)
                parent2 = self.tournament_selection(population)
                
                child1, child2 = self.crossover(parent1, parent2)
                child1 = self.mutate(child1)
                child2 = self.mutate(child2)
                
                self.evaluate_individual(child1, scenarios)
                self.evaluate_individual(child2, scenarios)
                
                offspring.extend([child1, child2])
            
            # 合并父代和子代
            combined_population = population + offspring
            
            # 非支配排序
            fronts = self.fast_non_dominated_sort(combined_population)
            
            # 选择下一代
            new_population = []
            for front in fronts:
                if len(new_population) + len(front) <= self.population_size:
                    self.calculate_crowding_distance(front)
                    new_population.extend(front)
                else:
                    self.calculate_crowding_distance(front)
                    front.sort(key=lambda x: x.crowding_distance, reverse=True)
                    remaining = self.population_size - len(new_population)
                    new_population.extend(front[:remaining])
                    break
            
            population = new_population
            
            # 记录最优前沿
            if fronts:
                best_front = fronts[0]
                avg_objectives = np.mean([ind.objectives for ind in best_front], axis=0)
                evolution_history.append(avg_objectives)
        
        self.final_population = population
        self.evolution_history = evolution_history
        
        return population[:min(10, len(population))]  # 返回前10个解
    
    def extract_solutions(self, pareto_solutions):
        """提取帕累托最优解"""
        solutions_data = []
        
        for i, individual in enumerate(pareto_solutions):
            # 分配组别
            groups = individual.assign_groups(self.bmi_values)
            
            # 计算每组的统计信息
            group_info = []
            actual_group_count = 0
            for group_id in range(individual.n_groups):
                group_mask = (groups == group_id)
                if not np.any(group_mask):
                    continue
                
                actual_group_count += 1
                group_bmis = self.bmi_values[group_mask]
                group_times = self.achievement_times[group_mask]
                
                # 确保检测时点索引正确
                if group_id < len(individual.detection_times):
                    detection_time = individual.detection_times[group_id]
                else:
                    detection_time = individual.detection_times[-1]
                
                achievement_rate = np.mean(group_times <= detection_time)
                
                group_info.append({
                    '组别': f'组{actual_group_count}',
                    'BMI下界': np.min(group_bmis),
                    'BMI上界': np.max(group_bmis),
                    '样本数': np.sum(group_mask),
                    '平均BMI': np.mean(group_bmis),
                    '检测时点_天': detection_time - 63-56,
                    '检测时点_周': detection_time / 7 - 9-8,
                    '达标率': achievement_rate,
                    '平均达标时间': np.mean(group_times)
                })
            
            solutions_data.append({
                '解编号': i + 1,
                '分组数': individual.n_groups,
                '总体风险': individual.objectives[0],
                '时间方差': individual.objectives[1],
                '组间不平衡': individual.objectives[2],
                '组别详情': group_info
            })
        
        return solutions_data
    
    def save_results(self, solutions_data):
        """保存结果"""
        # 保存帕累托最优解汇总
        summary_data = []
        detailed_data = []
        
        for solution in solutions_data:
            summary_data.append({
                '解编号': solution['解编号'],
                '分组数': solution['分组数'],
                '总体风险': solution['总体风险'],
                '时间方差': solution['时间方差'],
                '组间不平衡': solution['组间不平衡']
            })
            
            # 详细分组信息
            for group in solution['组别详情']:
                detailed_data.append({
                    '解编号': solution['解编号'],
                    '组别': group['组别'],
                    'BMI区间': f"[{group['BMI下界']:.1f}, {group['BMI上界']:.1f}]",
                    '样本数': group['样本数'],
                    '平均BMI': group['平均BMI'],
                    '检测时点_周': f"{group['检测时点_周']:.1f}周",
                    '达标率': f"{group['达标率']*100:.1f}%",
                    '平均达标时间': group['平均达标时间']
                })
        
        # 保存文件
        pd.DataFrame(summary_data).to_excel(
            f'{self.results_dir}/NSGA2帕累托最优解汇总.xlsx'
        )
        
        pd.DataFrame(detailed_data).to_excel(
            f'{self.results_dir}/NSGA2详细分组结果.xlsx'
        )
        
        # 保存进化历史
        evolution_df = pd.DataFrame(self.evolution_history, 
                                  columns=['平均风险', '平均方差', '平均不平衡'])
        evolution_df['代数'] = range(len(self.evolution_history))
        evolution_df.to_excel(
            f'{self.results_dir}/NSGA2进化历史.xlsx'
        )

    def run_robust_optimization(self):
        """运行鲁棒优化"""
        print("开始鲁棒随机NSGA-II规划模型...")
        print("="*60)
        
        # 加载数据
        if not self.load_processed_data():
            return False
        
        # 运行NSGA-II算法
        pareto_solutions = self.nsga2_main_loop()
        
        # 提取解决方案
        solutions_data = self.extract_solutions(pareto_solutions)
        
        # 保存结果
        self.save_results(solutions_data)

        print("\n" + "="*60)
        print("鲁棒NSGA-II优化完成！")
        print(f"找到{len(pareto_solutions)}个帕累托最优解")
        
        # 输出最佳解
        best_solution = min(pareto_solutions, key=lambda x: x.objectives[0])  # 风险最小
        print(f"\n风险最小解：")
        print(f"  分组数：{best_solution.n_groups}")
        print(f"  总体风险：{best_solution.objectives[0]:.4f}")
        print(f"  时间方差：{best_solution.objectives[1]:.2f}")
        print(f"  组间不平衡：{best_solution.objectives[2]:.4f}")
        
        return True

def main():
    """主程序入口"""
    model = RobustNSGA2Model()
    model.run_robust_optimization()

if __name__ == "__main__":
    main()
