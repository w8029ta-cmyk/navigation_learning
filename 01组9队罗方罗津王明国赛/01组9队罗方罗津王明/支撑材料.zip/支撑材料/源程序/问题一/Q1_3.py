import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.font_manager import FontProperties
import os
import warnings

warnings.filterwarnings('ignore')


class SCIPlotter:
    def __init__(self):
        """SCI期刊标准绘图器初始化"""
        self.setup_chinese_font()
        self.setup_sci_style()
        self.output_dir = "问题一_图"
        self.load_data()

        # 创建输出目录（如果不存在）
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

    def setup_chinese_font(self):
        """
        设置中文字体支持

        尝试加载Windows系统字体以确保中文显示正常
        优先顺序：黑体 > 微软雅黑 > 宋体
        """
        font_paths = [
            'C:/Windows/Fonts/simhei.ttf',  # 黑体（优先）
            'C:/Windows/Fonts/msyh.ttc',  # 微软雅黑
            'C:/Windows/Fonts/simsun.ttc',  # 宋体
        ]

        self.font_prop = None
        for path in font_paths:
            if os.path.exists(path):
                try:
                    # 创建字体属性对象
                    self.font_prop = FontProperties(fname=path)
                    # 设置全局字体配置
                    plt.rcParams['font.family'] = self.font_prop.get_name()
                    plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
                    print(f"成功加载字体: {path}")
                    break
                except Exception as e:
                    print(f"加载字体失败 {path}: {e}")
                    continue

    def setup_sci_style(self):
        """
        配置SCI期刊要求的绘图风格

        包括：分辨率、字体大小、线条粗细、网格样式等
        符合主流SCI期刊的图表格式要求
        """
        plt.rcParams.update({
            'figure.dpi': 300,  # 高分辨率显示
            'savefig.dpi': 300,  # 高分辨率保存
            'font.size': 13,  # 统一字体大小
            'axes.linewidth': 1.2,  # 坐标轴线宽
            'axes.labelsize': 13,  # 坐标轴标签大小
            'axes.titlesize': 13,  # 标题字体大小
            'xtick.labelsize': 13,  # X轴刻度标签大小
            'ytick.labelsize': 13,  # Y轴刻度标签大小
            'legend.fontsize': 13,  # 图例字体大小
            'figure.figsize': (8, 6),  # 默认图表尺寸
            'axes.grid': True,  # 启用网格
            'grid.alpha': 0.3,  # 网格透明度
            'grid.linestyle': '--',  # 网格线样式
            'axes.spines.top': False,  # 隐藏顶部边框
            'axes.spines.right': False,  # 隐藏右侧边框
            'grid.linewidth': 0.5  # 网格线宽度
        })

    def load_data(self):
        """
        加载并预处理男胎数据

        功能包括：
        1. 读取Excel数据文件
        2. 孕周格式标准化转换
        3. 数值型数据转换
        4. 数据有效性过滤
        """
        # 读取原始数据
        self.male_data = pd.read_excel('男胎数据_处理后.xlsx')

        def convert_pregnancy_week(week_str):
            """
            孕周格式转换函数

            将'12w+3'格式的孕周转换为数值型周数（如12.4286）
            支持格式：'12w+3', '12.5', 12.5

            Args:
                week_str: 孕周字符串或数值

            Returns:
                float: 转换后的孕周数值，转换失败返回NaN
            """
            try:
                # 处理空值和空字符串
                if pd.isna(week_str) or week_str == '':
                    return np.nan

                week_str = str(week_str).strip()

                # 处理'w'格式（如：12w+3）
                if 'w' in week_str:
                    parts = week_str.split('w')
                    weeks = float(parts[0])  # 整数周部分
                    days = 0

                    # 处理天数部分（如：+3）
                    if len(parts) > 1 and '+' in parts[1]:
                        days = float(parts[1].replace('+', ''))

                    # 转换为小数周数
                    return weeks + days / 7.0
                else:
                    # 直接转换为浮点数
                    return float(week_str)
            except (ValueError, TypeError):
                # 转换失败返回NaN
                return np.nan

        # 应用孕周转换
        if '检测孕周' in self.male_data.columns:
            self.male_data['检测孕周'] = self.male_data['检测孕周'].apply(convert_pregnancy_week)

        # 数值型列转换
        numeric_columns = ['Y染色体浓度', '检测孕周', '孕妇BMI', '年龄', '身高', '体重']
        for col in numeric_columns:
            if col in self.male_data.columns:
                # 转换为数值型，无效值转为NaN
                self.male_data[col] = pd.to_numeric(self.male_data[col], errors='coerce')

        # 过滤掉Y染色体浓度为空的记录
        self.male_data = self.male_data[self.male_data['Y染色体浓度'].notna()]
        print(f"成功加载数据，共{len(self.male_data)}条有效记录")

    def save_figure(self, filename, dpi=300):
        """
        保存图表到文件

        Args:
            filename: 输出文件名
            dpi: 输出分辨率，默认300dpi（SCI期刊要求）
        """
        plt.savefig(f'{self.output_dir}/{filename}',
                    bbox_inches='tight',  # 紧凑布局
                    dpi=dpi,  # 高分辨率
                    facecolor='white',  # 白色背景
                    edgecolor='none')  # 无边框
        plt.close()  # 关闭当前图表释放内存

    def plot_correlation_heatmap(self):
        """
        绘制相关性热力图

        展示Y染色体浓度与各孕妇指标之间的相关性矩阵
        使用三角掩码避免重复显示，颜色映射表示相关性强弱
        """
        print("正在绘制相关性热力图...")

        # 选择需要分析的相关性变量
        analysis_variables = ['Y染色体浓度', '检测孕周', '孕妇BMI', '年龄', '身高', '体重']
        correlation_data = self.male_data[analysis_variables].corr()

        # 创建图表
        fig, ax = plt.subplots(figsize=(8, 6))

        # 创建三角掩码（避免重复显示）
        triangular_mask = np.triu(np.ones_like(correlation_data, dtype=bool))

        # 绘制热力图
        sns.heatmap(correlation_data,
                    mask=triangular_mask,
                    annot=True,  # 显示数值
                    cmap='RdBu_r',  # 红蓝对比色系
                    center=0,  # 颜色中心点为0
                    square=True,  # 正方形单元格
                    fmt='.3f',  # 数值格式
                    cbar_kws={'shrink': 0.8},  # 颜色条尺寸
                    annot_kws={'fontsize': 11})  # 数值字体大小

        # 设置标题
        ax.set_title('胎儿Y染色体浓度与孕妇指标相关性分析',
                     fontproperties=self.font_prop,
                     pad=20)  # 标题间距

        # 设置坐标轴标签
        ax.set_xticklabels(analysis_variables,
                           fontproperties=self.font_prop,
                           rotation=45)  # X轴标签旋转45度
        ax.set_yticklabels(analysis_variables,
                           fontproperties=self.font_prop,
                           rotation=0)  # Y轴标签不旋转

        self.save_figure('相关性热力图.png')

    def plot_normality_test_results(self):
        """
        绘制正态性检验结果可视化

        展示Shapiro-Wilk和D'Agostino两种正态性检验的p值结果
        使用对数变换处理极小的p值，便于可视化比较
        """
        print("正在绘制正态性检验结果...")

        # 读取正态性检验结果数据
        normality_results_df = pd.read_excel('问题一_表/正态性检验结果表.xlsx')

        # 创建图表
        fig, ax = plt.subplots(figsize=(8, 6))

        # 提取检验数据
        variable_names = normality_results_df['变量名'].values
        shapiro_p_values = pd.to_numeric(normality_results_df['Shapiro_Wilk检验_p值'], errors='coerce')
        dagostino_p_values = pd.to_numeric(normality_results_df['D_Agostino检验_p值'], errors='coerce')

        # 对p值进行对数变换（避免极值影响可视化）
        shapiro_log_p = -np.log10(shapiro_p_values.fillna(1e-10))
        dagostino_log_p = -np.log10(dagostino_p_values.fillna(1e-10))

        # 设置条形图位置和宽度
        x_positions = np.arange(len(variable_names))
        bar_width = 0.35

        # 绘制两种检验的条形图
        shapiro_bars = ax.bar(x_positions - bar_width / 2, shapiro_log_p, bar_width,
                              label='Shapiro-Wilk检验',
                              color='steelblue', alpha=0.8)
        dagostino_bars = ax.bar(x_positions + bar_width / 2, dagostino_log_p, bar_width,
                                label="D'Agostino检验",
                                color='lightcoral', alpha=0.8)

        # 添加显著性水平参考线（p=0.05）
        significance_threshold = -np.log10(0.05)
        ax.axhline(y=significance_threshold, color='red', linestyle='--', alpha=0.7,
                   label='显著性水平(p=0.05)')

        # 设置坐标轴标签和标题
        ax.set_xlabel('变量名', fontproperties=self.font_prop)
        ax.set_ylabel('-lg(p值)', fontproperties=self.font_prop)
        ax.set_title('各变量正态性检验结果', fontproperties=self.font_prop, pad=20)

        # 设置X轴刻度标签
        ax.set_xticks(x_positions)
        ax.set_xticklabels(variable_names, fontproperties=self.font_prop, rotation=45)

        # 添加图例
        ax.legend(prop=self.font_prop)

        self.save_figure('正态性检验结果.png')

    def plot_hexbin_correlation(self):
        """
        绘制蜂窝图展示Y染色体浓度与孕周关系

        使用六边形分箱图展示二维数据的密度分布
        颜色深浅表示数据点密集程度，适合大量数据的可视化
        """
        print("正在绘制蜂窝图...")

        # 创建图表
        fig, ax = plt.subplots(figsize=(8, 6))

        # 获取有效数据（去除NaN值）
        valid_data = self.male_data[['Y染色体浓度', '检测孕周']].dropna()

        if len(valid_data) > 0:
            x_data = valid_data['检测孕周']
            y_data = valid_data['Y染色体浓度']

            # 绘制六边形分箱图
            hexbin_plot = ax.hexbin(x_data, y_data,
                                    gridsize=25,  # 网格大小
                                    cmap='plasma',  # 颜色映射
                                    alpha=0.8,  # 透明度
                                    mincnt=1)  # 最小计数

            # 添加颜色条
            colorbar = plt.colorbar(hexbin_plot, ax=ax)
            colorbar.set_label('数据点密度', fontproperties=self.font_prop)

            # 设置坐标轴标签和标题
            ax.set_xlabel('检测孕周', fontproperties=self.font_prop)
            ax.set_ylabel('Y染色体浓度', fontproperties=self.font_prop)
            ax.set_title('Y染色体浓度与检测孕周关系（蜂窝图）',
                         fontproperties=self.font_prop,
                         pad=20)

        self.save_figure('蜂窝图.png')

    def plot_feature_importance(self):
        """
        绘制特征重要性排序图

        基于贝叶斯岭回归系数展示各预测变量的重要性
        按系数绝对值排序，正负系数用不同颜色区分
        """
        print("正在绘制特征重要性...")

        # 读取贝叶斯回归系数数据
        coefficient_df = pd.read_excel('问题一_表/贝叶斯岭回归系数分析表.xlsx')

        # 创建图表
        fig, ax = plt.subplots(figsize=(8, 6))

        # 提取数据
        predictor_variables = coefficient_df['预测变量'].values
        bayesian_coefficients = coefficient_df['贝叶斯系数估计'].values
        importance_ranking = coefficient_df['重要性排名'].values

        # 按重要性排名排序
        sorted_indices = np.argsort(importance_ranking)
        sorted_variables = predictor_variables[sorted_indices]
        sorted_coefficients = bayesian_coefficients[sorted_indices]

        # 设置颜色（正系数绿色，负系数红色）
        positive_color = 'forestgreen'
        negative_color = 'firebrick'
        bar_colors = [positive_color if coef > 0 else negative_color
                      for coef in sorted_coefficients]

        # 绘制水平条形图（按系数绝对值）
        importance_bars = ax.barh(range(len(sorted_variables)),
                                  np.abs(sorted_coefficients),
                                  color=bar_colors,
                                  alpha=0.8,
                                  edgecolor='white',
                                  linewidth=0.5)

        # 设置Y轴标签
        ax.set_yticks(range(len(sorted_variables)))
        ax.set_yticklabels(sorted_variables, fontproperties=self.font_prop)

        # 设置坐标轴标签和标题
        ax.set_xlabel('|贝叶斯回归系数|', fontproperties=self.font_prop)
        ax.set_title('特征重要性排序（按系数绝对值）',
                     fontproperties=self.font_prop,
                     pad=20)

        # 添加系数数值标签
        for i, (bar, coefficient) in enumerate(zip(importance_bars, sorted_coefficients)):
            bar_width = bar.get_width()
            ax.annotate(f'{coefficient:.4f}',
                        xy=(bar_width, bar.get_y() + bar.get_height() / 2),
                        xytext=(5, 0),
                        textcoords='offset points',
                        va='center',
                        ha='left')

        # 创建图例
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor=positive_color, label='正系数'),
            Patch(facecolor=negative_color, label='负系数')
        ]
        ax.legend(handles=legend_elements, prop=self.font_prop)

        self.save_figure('特征重要性.png')

    def plot_robust_comparison(self):
        """
        绘制鲁棒回归模型性能对比图

        使用双Y轴展示不同鲁棒回归方法的R²和RMSE指标
        便于综合评估模型性能
        """
        print("正在绘制鲁棒回归对比...")

        # 读取鲁棒回归比较数据
        robust_comparison_df = pd.read_excel('问题一_表/鲁棒回归模型比较表.xlsx')

        # 创建图表
        fig, ax = plt.subplots(figsize=(8, 6))

        # 提取模型性能数据
        model_names = robust_comparison_df['鲁棒回归方法'].values
        r2_scores = robust_comparison_df['决定系数R²'].values
        rmse_values = robust_comparison_df['均方根误差RMSE'].values

        # 创建双Y轴
        secondary_axis = ax.twinx()

        # 设置颜色
        r2_color = 'royalblue'
        rmse_color = 'darkorange'

        # 绘制R²柱状图（主Y轴）
        r2_bars = ax.bar(np.arange(len(model_names)) - 0.1, r2_scores, 0.2,
                         color=r2_color, alpha=0.8, label='R²')

        # 绘制RMSE柱状图（次Y轴）
        rmse_bars = secondary_axis.bar(np.arange(len(model_names)) + 0.1, rmse_values, 0.2,
                                       color=rmse_color, alpha=0.8, label='RMSE')

        # 设置坐标轴标签
        ax.set_xlabel('鲁棒回归模型', fontproperties=self.font_prop)
        ax.set_ylabel('R²', fontproperties=self.font_prop, color=r2_color)
        secondary_axis.set_ylabel('RMSE', fontproperties=self.font_prop, color=rmse_color)

        # 设置标题
        ax.set_title('鲁棒回归模型性能对比', fontproperties=self.font_prop, pad=20)

        # 设置X轴刻度标签
        ax.set_xticks(range(len(model_names)))
        ax.set_xticklabels(model_names, fontproperties=self.font_prop)

        # 添加数值标签
        for i, (r2_bar, rmse_bar) in enumerate(zip(r2_bars, rmse_bars)):
            r2_height = r2_bar.get_height()
            rmse_height = rmse_bar.get_height()

            # R²数值标签
            ax.annotate(f'{r2_height:.4f}',
                        xy=(r2_bar.get_x() + r2_bar.get_width() / 2, r2_height),
                        xytext=(0, 3),
                        textcoords="offset points",
                        ha='center',
                        va='bottom')

            # RMSE数值标签
            secondary_axis.annotate(f'{rmse_height:.6f}',
                                    xy=(rmse_bar.get_x() + rmse_bar.get_width() / 2, rmse_height),
                                    xytext=(0, 3),
                                    textcoords="offset points",
                                    ha='center',
                                    va='bottom')

        # 合并图例
        r2_lines, r2_labels = ax.get_legend_handles_labels()
        rmse_lines, rmse_labels = secondary_axis.get_legend_handles_labels()
        ax.legend(r2_lines + rmse_lines, r2_labels + rmse_labels,
                  prop=self.font_prop,
                  loc='upper center')

        self.save_figure('鲁棒回归对比.png')

    def generate_all_plots(self):
        """
        批量生成所有统计分析图表

        按顺序执行所有绘图函数，统一错误处理
        返回生成结果状态
        """
        print("开始批量生成SCI标准图表...")
        print("=" * 50)

        try:
            # 按顺序执行所有绘图函数
            self.plot_correlation_heatmap()
            self.plot_normality_test_results()
            self.plot_hexbin_correlation()
            self.plot_feature_importance()
            self.plot_robust_comparison()

            print("\n" + "=" * 50)
            print("所有SCI标准图表生成完成！")
            print(f"图表保存位置: {self.output_dir}")

            return True

        except Exception as error:
            print(f"图表生成过程中出现错误: {error}")
            return False


def main():
    """主程序入口"""
    plotter = SCIPlotter()
    plotter.generate_all_plots()


if __name__ == "__main__":
    main()