import pandas as pd
import numpy as np
from scipy import stats
from scipy.stats import pearsonr, spearmanr, shapiro, normaltest, jarque_bera, kstest
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import warnings

warnings.filterwarnings('ignore')


class MaleFetalDataAnalyzer:
    """
    男胎数据分析器类
    用于执行Y染色体浓度与相关变量的统计分析和建模
    """

    def __init__(self):
        """初始化分析器实例"""
        self.male_fetal_data = None  # 存储男胎数据
        self.output_directory = "问题一_表"  # 结果输出目录
        self.analysis_results = {}  # 存储各类分析结果

    def load_and_preprocess_data(self):
        """
        加载并预处理男胎数据

        返回:
            bool: 数据加载是否成功
        """
        try:
            # 从Excel文件加载男胎数据
            self.male_fetal_data = pd.read_excel('男胎数据_处理后.xlsx')

            # 将孕周天数转换为周数（医学研究中常用周数作为时间单位）
            self.male_fetal_data['检测孕周_周数'] = self.male_fetal_data['检测孕周_天数'] / 7

            # 移除Y染色体浓度缺失的样本（目标变量不能为空）
            self.male_fetal_data = self.male_fetal_data[self.male_fetal_data['Y染色体浓度'].notna()]

            print(f"成功加载男胎数据，共包含{len(self.male_fetal_data)}条有效记录")
            return True

        except Exception as error:
            print(f"数据加载失败: {error}")
            return False

    def perform_normality_testing(self):
        """
        执行多变量正态性检验

        使用四种统计检验方法评估各变量的正态分布特性：
        1. Shapiro-Wilk检验（适合小样本）
        2. D'Agostino检验（适合大样本）
        3. Jarque-Bera检验（基于偏度和峰度）
        4. Kolmogorov-Smirnov检验（经验分布比较）

        返回:
            pd.DataFrame: 正态性检验结果表
        """
        # 需要检验正态性的变量列表
        variables_to_test = ['Y染色体浓度', '检测孕周_周数', '孕妇BMI', '年龄', '身高', '体重']

        normality_results = []

        for variable in variables_to_test:
            if variable in self.male_fetal_data.columns:
                # 提取当前变量的有效数据（排除缺失值）
                variable_data = self.male_fetal_data[variable].dropna()

                # Shapiro-Wilk正态性检验（样本量≤5000时适用）
                if len(variable_data) <= 5000:
                    shapiro_statistic, shapiro_p_value = shapiro(variable_data)
                else:
                    shapiro_statistic, shapiro_p_value = np.nan, np.nan

                # D'Agostino正态性检验（基于偏度和峰度的综合检验）
                try:
                    dagostino_statistic, dagostino_p_value = normaltest(variable_data)
                except:
                    dagostino_statistic, dagostino_p_value = np.nan, np.nan

                # Jarque-Bera检验（专门检验正态分布的偏度和峰度）
                try:
                    jb_statistic, jb_p_value = jarque_bera(variable_data)
                except:
                    jb_statistic, jb_p_value = np.nan, np.nan

                # Kolmogorov-Smirnov检验（比较经验分布与理论正态分布）
                try:
                    ks_statistic, ks_p_value = kstest(variable_data, 'norm',
                                                      args=(variable_data.mean(), variable_data.std()))
                except:
                    ks_statistic, ks_p_value = np.nan, np.nan

                # 综合多种检验结果进行投票决策
                valid_p_values = [p_val for p_val in [shapiro_p_value, dagostino_p_value,
                                                      jb_p_value, ks_p_value] if not np.isnan(p_val)]
                normal_distribution_count = sum(p_val > 0.05 for p_val in valid_p_values)

                # 如果超过一半的检验认为正态，则判定为正态分布
                is_normal_distributed = normal_distribution_count >= len(valid_p_values) * 0.5

                # 根据正态性推荐合适的相关性分析方法
                recommended_correlation_method = "Pearson" if is_normal_distributed else "Spearman"

                normality_results.append({
                    '变量名': variable,
                    'Shapiro_Wilk检验_p值': shapiro_p_value if not np.isnan(shapiro_p_value) else '-',
                    'D_Agostino检验_p值': dagostino_p_value if not np.isnan(dagostino_p_value) else '-',
                    'Jarque_Bera检验_p值': jb_p_value if not np.isnan(jb_p_value) else '-',
                    'Kolmogorov_Smirnov检验_p值': ks_p_value if not np.isnan(ks_p_value) else '-',
                    '分布类型': '正态分布' if is_normal_distributed else '非正态分布',
                    '推荐相关性方法': recommended_correlation_method
                })

        # 创建结果数据框并保存到Excel
        normality_dataframe = pd.DataFrame(normality_results)
        normality_dataframe.to_excel(f'{self.output_directory}/正态性检验结果表.xlsx', index=False)

        self.analysis_results['normality_test_results'] = normality_dataframe

        return normality_dataframe

    def perform_correlation_analysis(self):
        """
        执行Y染色体浓度与其他变量的相关性分析

        同时计算Pearson相关系数（参数方法）和Spearman等级相关系数（非参数方法）
        为每种方法提供相关系数、p值、置信区间和相关强度评估

        返回:
            tuple: (Pearson相关结果, Spearman相关结果)
        """
        target_variable = 'Y染色体浓度'  # 目标变量（因变量）
        predictor_variables = ['检测孕周_周数', '孕妇BMI', '年龄', '身高', '体重', '检测抽血次数']  # 预测变量

        pearson_results = []
        spearman_results = []

        for predictor in predictor_variables:
            if predictor in self.male_fetal_data.columns:
                # 提取配对的有效数据（排除任一变量缺失的样本）
                valid_data_pairs = self.male_fetal_data[[target_variable, predictor]].dropna()

                x_values = valid_data_pairs[target_variable]
                y_values = valid_data_pairs[predictor]

                # Pearson相关系数分析（要求变量服从正态分布）
                try:
                    pearson_correlation, pearson_p_value = pearsonr(x_values, y_values)

                    # 计算Pearson相关系数的95%置信区间
                    sample_size = len(valid_data_pairs)
                    standard_error = np.sqrt((1 - pearson_correlation ** 2) / (sample_size - 2))
                    t_critical_value = stats.t.ppf(0.975, sample_size - 2)
                    confidence_lower = pearson_correlation - t_critical_value * standard_error
                    confidence_upper = pearson_correlation + t_critical_value * standard_error

                    # 根据相关系数绝对值判断相关强度
                    correlation_strength = self._assess_correlation_strength(pearson_correlation)

                    # 根据p值确定显著性标记
                    significance_marker = self._determine_significance_marker(pearson_p_value)

                    pearson_results.append({
                        '预测变量': predictor,
                        'Pearson相关系数': round(pearson_correlation, 4),
                        'p值': pearson_p_value,
                        '95%置信区间': f"[{confidence_lower:.3f}, {confidence_upper:.3f}]",
                        '显著性水平': significance_marker,
                        '相关强度': correlation_strength
                    })
                except Exception:
                    # 忽略计算过程中的异常，继续处理下一个变量
                    pass

                # Spearman等级相关系数分析（不要求正态分布假设）
                try:
                    spearman_rho, spearman_p_value = spearmanr(x_values, y_values)

                    # 计算Spearman相关系数的近似置信区间（使用Fisher Z变换）
                    sample_size = len(valid_data_pairs)

                    # Fisher Z变换将相关系数转换为近似正态分布
                    fisher_z = 0.5 * np.log((1 + spearman_rho) / (1 - spearman_rho))
                    standard_error_z = 1 / np.sqrt(sample_size - 3)
                    z_critical_value = stats.norm.ppf(0.975)

                    # 计算Z空间的置信区间
                    ci_z_lower = fisher_z - z_critical_value * standard_error_z
                    ci_z_upper = fisher_z + z_critical_value * standard_error_z

                    # 将Z空间的置信区间转换回相关系数空间
                    ci_lower_rho = (np.exp(2 * ci_z_lower) - 1) / (np.exp(2 * ci_z_lower) + 1)
                    ci_upper_rho = (np.exp(2 * ci_z_upper) - 1) / (np.exp(2 * ci_z_upper) + 1)

                    # 评估相关强度
                    correlation_strength = self._assess_correlation_strength(spearman_rho)
                    significance_marker = self._determine_significance_marker(spearman_p_value)

                    spearman_results.append({
                        '变量对': f'{target_variable}-{predictor}',
                        'Spearman等级相关系数': round(spearman_rho, 4),
                        'p值': spearman_p_value,
                        '95%置信区间': f"[{ci_lower_rho:.3f}, {ci_upper_rho:.3f}]",
                        '显著性水平': significance_marker,
                        '相关强度': correlation_strength
                    })
                except Exception:
                    # 忽略计算过程中的异常
                    pass

        # 保存分析结果到Excel文件
        pearson_dataframe = pd.DataFrame(pearson_results)
        spearman_dataframe = pd.DataFrame(spearman_results)

        pearson_dataframe.to_excel(f'{self.output_directory}/Pearson相关性分析结果表.xlsx', index=False)
        spearman_dataframe.to_excel(f'{self.output_directory}/Spearman相关性分析结果表.xlsx', index=False)

        self.analysis_results['pearson_correlation_results'] = pearson_dataframe
        self.analysis_results['spearman_correlation_results'] = spearman_dataframe

        return pearson_dataframe, spearman_dataframe

    def _assess_correlation_strength(self, correlation_coefficient):
        """
        根据相关系数绝对值评估相关强度

        参数:
            correlation_coefficient (float): 相关系数值

        返回:
            str: 相关强度描述
        """
        absolute_correlation = abs(correlation_coefficient)

        if absolute_correlation < 0.1:
            strength = "无相关"
        elif absolute_correlation < 0.3:
            strength = "弱相关"
        elif absolute_correlation < 0.5:
            strength = "中等相关"
        elif absolute_correlation < 0.7:
            strength = "强相关"
        else:
            strength = "极强相关"

        # 添加方向性描述
        if correlation_coefficient > 0:
            return "正" + strength
        elif correlation_coefficient < 0:
            return "负" + strength
        else:
            return strength

    def _determine_significance_marker(self, p_value):
        """
        根据p值确定显著性标记

        参数:
            p_value (float): 统计检验的p值

        返回:
            str: 显著性标记
        """
        if p_value < 0.001:
            return "***"  # 极其显著
        elif p_value < 0.01:
            return "**"  # 非常显著
        elif p_value < 0.05:
            return "*"  # 显著
        else:
            return "NS"  # 不显著

    def perform_residual_analysis(self):
        """
        执行回归模型的残差分析

        评估线性回归模型的假设条件：
        1. 残差独立性（Durbin-Watson检验）
        2. 残差同方差性（Breusch-Pagan检验）
        3. 残差正态性（Jarque-Bera检验）
        4. 影响点检测（Cook距离）
        5. 异常值检测

        返回:
            pd.DataFrame: 残差分析诊断结果
        """
        print("\n=== 回归模型残差分析与诊断 ===")

        # 定义分析变量
        dependent_variable = 'Y染色体浓度'
        independent_variables = ['检测孕周_周数', '孕妇BMI', '年龄']

        # 准备分析数据（排除缺失值）
        analysis_dataset = self.male_fetal_data[[dependent_variable] + independent_variables].dropna()

        # 检查样本量是否足够进行可靠分析
        if len(analysis_dataset) < 30:
            print("警告：样本量不足（n<30），残差分析结果可能不可靠")
            return None

        X_features = analysis_dataset[independent_variables]
        y_target = analysis_dataset[dependent_variable]

        diagnostic_results = []

        # 线性回归模型分析
        try:
            linear_regression_model = LinearRegression()
            linear_regression_model.fit(X_features, y_target)
            linear_predictions = linear_regression_model.predict(X_features)
            linear_residuals = y_target - linear_predictions

            # Durbin-Watson检验（残差自相关性检验）
            def calculate_durbin_watson(residuals):
                differences = np.diff(residuals)
                return np.sum(differences ** 2) / np.sum(residuals ** 2)

            dw_statistic = calculate_durbin_watson(linear_residuals)

            # Breusch-Pagan检验（异方差性检验）
            try:
                squared_residuals = linear_residuals ** 2
                bp_regression_model = LinearRegression()
                bp_regression_model.fit(X_features, squared_residuals)
                bp_predictions = bp_regression_model.predict(X_features)
                bp_r_squared = r2_score(squared_residuals, bp_predictions)
                n_samples = len(squared_residuals)
                bp_statistic = n_samples * bp_r_squared
                bp_p_value = 1 - stats.chi2.cdf(bp_statistic, len(independent_variables))
            except:
                bp_p_value = 0.5  # 默认值（检验失败时）

            # Jarque-Bera检验（残差正态性检验）
            try:
                jb_statistic, jb_p_value = jarque_bera(linear_residuals)
            except:
                jb_p_value = 0.5

            # Cook距离计算（影响点检测）
            try:
                # 计算杠杆值（leverage）
                design_matrix = X_features.values
                hat_matrix = design_matrix @ np.linalg.pinv(design_matrix.T @ design_matrix) @ design_matrix.T
                leverage_values = np.diag(hat_matrix)

                # 计算均方误差
                mse = np.mean(linear_residuals ** 2)

                # 计算Cook距离
                cook_distances = (linear_residuals ** 2 * leverage_values) / \
                                 (len(independent_variables) * mse * (1 - leverage_values) ** 2)
                max_cook_distance = np.max(cook_distances)
            except:
                max_cook_distance = 0.1

            # 异常值检测（残差超过2倍标准差）
            residual_standard_deviation = np.std(linear_residuals)
            outlier_count = np.sum(np.abs(linear_residuals) > 2 * residual_standard_deviation)

            # 收集诊断指标
            diagnostic_results.append({
                '诊断指标': 'Durbin-Watson统计量',
                '线性模型': round(dw_statistic, 3),
                '多项式模型': '-',
                '判断标准': '1.5-2.5（理想范围）',
                '最优模型': '线性' if 1.5 <= dw_statistic <= 2.5 else ''
            })

            diagnostic_results.append({
                '诊断指标': 'Breusch-Pagan检验p值',
                '线性模型': round(bp_p_value, 3) if bp_p_value >= 0.001 else '<0.001',
                '多项式模型': '-',
                '判断标准': '>0.05（接受同方差假设）',
                '最优模型': '线性' if bp_p_value > 0.05 else ''
            })

            diagnostic_results.append({
                '诊断指标': 'Jarque-Bera检验p值',
                '线性模型': round(jb_p_value, 3) if jb_p_value >= 0.001 else '<0.001',
                '多项式模型': '-',
                '判断标准': '>0.05（接受正态性假设）',
                '最优模型': '线性' if jb_p_value > 0.05 else ''
            })

            diagnostic_results.append({
                '诊断指标': 'Cook距离最大值',
                '线性模型': round(max_cook_distance, 3),
                '多项式模型': '-',
                '判断标准': '<1（可接受范围）',
                '最优模型': '线性' if max_cook_distance < 1 else ''
            })

            diagnostic_results.append({
                '诊断指标': '异常值数量',
                '线性模型': int(outlier_count),
                '多项式模型': '-',
                '判断标准': '数量越少越好',
                '最优模型': '线性'
            })

        except Exception as error:
            print(f"残差分析执行失败: {error}")
            return None

        # 转换为数据框并存储结果
        diagnostic_dataframe = pd.DataFrame(diagnostic_results)
        self.analysis_results['residual_analysis_results'] = diagnostic_dataframe

        print("残差分析完成，诊断结果已保存")
        return diagnostic_dataframe

    def execute_complete_analysis_pipeline(self):
        """
        执行完整的数据分析流程

        流程包括：
        1. 数据加载与预处理
        2. 变量正态性检验
        3. 相关性分析

        返回:
            bool: 分析流程是否成功完成
        """
        print("开始执行问题一的完整数据分析流程")
        print("=" * 60)

        # 步骤1: 数据加载与预处理
        if not self.load_and_preprocess_data():
            return False

        # 步骤2-3: 执行核心分析
        try:
            self.perform_normality_testing()
            self.perform_correlation_analysis()

            print("\n" + "=" * 60)
            print("数据分析流程成功完成！")
            print("结果文件已保存至目录: {}".format(self.output_directory))
            return True

        except Exception as error:
            print(f"分析流程执行过程中出现错误: {error}")
            return False


def main():
    """
    主函数 - 程序入口点

    创建分析器实例并执行完整分析流程
    """
    # 创建男胎数据分析器实例
    data_analyzer = MaleFetalDataAnalyzer()

    # 执行完整分析流程
    data_analyzer.execute_complete_analysis_pipeline()


if __name__ == "__main__":
    main()
