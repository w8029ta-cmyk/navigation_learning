import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from sklearn.linear_model import BayesianRidge, HuberRegressor, RANSACRegressor
from sklearn.preprocessing import RobustScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.model_selection import cross_val_score
import warnings

warnings.filterwarnings('ignore')


class RobustBayesianRegressionAnalyzer:
    """
    鲁棒贝叶斯回归分析器

    该类实现了对Y染色体浓度数据的鲁棒回归和贝叶斯回归分析，
    包括Huber回归、RANSAC回归和贝叶斯岭回归等多种鲁棒建模方法。
    """

    def __init__(self):
        """初始化分析器实例"""
        self.male_fetal_dataset = None  # 存储男胎数据
        self.output_directory = "问题一_表"  # 结果输出目录
        self.analysis_results = {}  # 存储各类分析结果
        self.chinese_font_property = None  # 中文字体配置
        self._configure_chinese_font_support()

    def _configure_chinese_font_support(self):
        """
        配置中文字体支持，确保图表能正确显示中文

        尝试多种常见的中文字体路径，选择第一个可用的字体
        """
        chinese_font_paths = [
            'C:/Windows/Fonts/simhei.ttf',  # 黑体
            'C:/Windows/Fonts/msyh.ttc',  # 微软雅黑
            'C:/Windows/Fonts/simsun.ttc',  # 宋体
        ]

        for font_path in chinese_font_paths:
            try:
                import os
                if os.path.exists(font_path):
                    self.chinese_font_property = FontProperties(fname=font_path)
                    plt.rcParams['font.family'] = self.chinese_font_property.get_name()
                    plt.rcParams['axes.unicode_minus'] = False  # 正确显示负号
                    print(f"成功加载中文字体: {font_path}")
                    break
            except Exception as font_error:
                print(f"字体加载失败 {font_path}: {font_error}")
                continue

        if self.chinese_font_property is None:
            self.chinese_font_property = FontProperties()
            print("警告: 未找到合适的中文字体，图表可能无法正确显示中文")

    def load_and_preprocess_dataset(self):
        """
        加载并预处理男胎数据

        从Excel文件读取数据，进行孕周格式转换、数值化处理和缺失值清理

        返回:
            bool: 数据加载和预处理是否成功
        """
        try:
            # 从Excel文件加载原始数据
            self.male_fetal_dataset = pd.read_excel('男胎数据_处理后.xlsx')

            # 定义孕周字符串转换函数
            def convert_pregnancy_week_format(week_string):
                """
                将孕周字符串转换为数值格式（周数）

                支持格式: "12w", "12w+3", "12.5"等
                """
                try:
                    if pd.isna(week_string) or week_string == '':
                        return np.nan
                    week_string = str(week_string).strip()

                    # 处理"12w+3"格式
                    if 'w' in week_string:
                        week_parts = week_string.split('w')
                        base_weeks = float(week_parts[0])
                        additional_days = 0

                        # 处理"+天数"部分
                        if len(week_parts) > 1 and '+' in week_parts[1]:
                            additional_days = float(week_parts[1].replace('+', ''))

                        return base_weeks + additional_days / 7.0
                    else:
                        # 直接处理数值格式
                        return float(week_string)
                except ValueError:
                    return np.nan

            # 孕周数据格式转换
            if '检测孕周' in self.male_fetal_dataset.columns:
                self.male_fetal_dataset['检测孕周'] = self.male_fetal_dataset['检测孕周'].apply(
                    convert_pregnancy_week_format
                )

            # 数值型变量转换（确保所有数值列都是正确的数值类型）
            numerical_columns = ['Y染色体浓度', '检测孕周', '孕妇BMI', '年龄', '身高', '体重']
            for column in numerical_columns:
                if column in self.male_fetal_dataset.columns:
                    self.male_fetal_dataset[column] = pd.to_numeric(
                        self.male_fetal_dataset[column], errors='coerce'
                    )

            # 移除Y染色体浓度缺失的样本（目标变量不能为空）
            self.male_fetal_dataset = self.male_fetal_dataset[
                self.male_fetal_dataset['Y染色体浓度'].notna()
            ]

            print(f"数据加载和预处理完成，共包含{len(self.male_fetal_dataset)}条有效记录")
            return True

        except Exception as error:
            print(f"数据加载失败: {error}")
            return False

    def perform_bayesian_ridge_regression(self):
        """
        执行贝叶斯岭回归分析

        使用贝叶斯岭回归模型分析Y染色体浓度与多个预测变量的关系，
        提供后验分布估计和不确定性量化

        返回:
            tuple: (模型评估结果, 系数分析结果, 模型对象, 标准化特征, 目标变量)
        """
        print("\n=== 贝叶斯岭回归分析 ===")

        # 定义分析变量
        target_variable = 'Y染色体浓度'
        predictor_variables = ['检测孕周', '孕妇BMI', '年龄', '身高', '体重']

        # 准备完整数据集（排除任何缺失值）
        complete_dataset = self.male_fetal_dataset[[target_variable] + predictor_variables].dropna()

        # 检查样本量是否满足建模要求
        if len(complete_dataset) < 50:
            print("警告: 数据量不足（n<50），贝叶斯回归结果可能不稳定")
            return None

        feature_matrix = complete_dataset[predictor_variables]
        target_vector = complete_dataset[target_variable]

        # 使用鲁棒标准化处理特征（对异常值不敏感）
        robust_scaler = RobustScaler()
        scaled_features = robust_scaler.fit_transform(feature_matrix)
        scaled_features_dataframe = pd.DataFrame(scaled_features, columns=predictor_variables)

        # 配置贝叶斯岭回归模型参数
        bayesian_regression_model = BayesianRidge(
            alpha_1=1e-6,  # alpha参数的Gamma先验形状参数
            alpha_2=1e-6,  # alpha参数的Gamma先验速率参数
            lambda_1=1e-6,  # lambda参数的Gamma先验形状参数
            lambda_2=1e-6,  # lambda参数的Gamma先验速率参数
            compute_score=True,  # 计算边际似然分数
            fit_intercept=True  # 包含截距项
        )

        # 训练贝叶斯回归模型
        bayesian_regression_model.fit(scaled_features, target_vector)

        # 模型预测和不确定性估计
        predicted_values = bayesian_regression_model.predict(scaled_features)
        prediction_std = np.sqrt(bayesian_regression_model.sigma_)  # 预测标准差

        # 计算模型评估指标
        r_squared = r2_score(target_vector, predicted_values)
        root_mean_squared_error = np.sqrt(mean_squared_error(target_vector, predicted_values))
        mean_absolute_err = mean_absolute_error(target_vector, predicted_values)

        # 5折交叉验证评估模型稳定性
        cross_validation_scores = cross_val_score(
            bayesian_regression_model, scaled_features, target_vector,
            cv=5, scoring='r2'
        )
        cv_mean_r2 = cross_validation_scores.mean()
        cv_std_r2 = cross_validation_scores.std()

        # 获取后验分布参数
        noise_precision_posterior = bayesian_regression_model.alpha_  # 噪声精度后验估计
        weight_precision_posterior = bayesian_regression_model.lambda_  # 权重精度后验估计

        # 构建模型评估结果表
        model_evaluation_results = [{
            '模型类型': '贝叶斯岭回归',
            '决定系数R²': round(r_squared, 4),
            '均方根误差RMSE': round(root_mean_squared_error, 6),
            '平均绝对误差MAE': round(mean_absolute_err, 6),
            '交叉验证R²均值': round(cv_mean_r2, 4),
            '交叉验证R²标准差': round(cv_std_r2, 4),
            '噪声精度后验估计': f"{noise_precision_posterior:.6f}",
            '权重精度后验估计': f"{weight_precision_posterior:.6f}",
            '预测不确定性均值': round(np.mean(prediction_std), 6)
        }]

        evaluation_dataframe = pd.DataFrame(model_evaluation_results)

        # 系数分析和不确定性量化
        coefficient_results = []

        for index, variable_name in enumerate(predictor_variables):
            coefficient_value = bayesian_regression_model.coef_[index]

            # 计算系数后验标准差（基于后验协方差矩阵）
            if hasattr(bayesian_regression_model, 'sigma_'):
                coefficient_std = np.sqrt(np.diag(bayesian_regression_model.sigma_)[index])
            else:
                coefficient_std = 0.01  # 默认值

            # 计算95%可信区间
            confidence_lower = coefficient_value - 1.96 * coefficient_std
            confidence_upper = coefficient_value + 1.96 * coefficient_std

            # 统计显著性判断（可信区间是否包含0）
            is_statistically_significant = not (confidence_lower <= 0 <= confidence_upper)

            coefficient_results.append({
                '预测变量': variable_name,
                '贝叶斯系数估计': round(coefficient_value, 6),
                '后验标准差': round(coefficient_std, 6),
                '95%可信区间': f"[{confidence_lower:.6f}, {confidence_upper:.6f}]",
                '统计显著性': '是' if is_statistically_significant else '否',
                '重要性排名': 0  # 待后续排序
            })

        # 按系数绝对值排序确定变量重要性
        coefficient_dataframe = pd.DataFrame(coefficient_results)
        coefficient_dataframe['系数绝对值'] = np.abs(coefficient_dataframe['贝叶斯系数估计'])
        coefficient_dataframe = coefficient_dataframe.sort_values('系数绝对值', ascending=False)
        coefficient_dataframe['重要性排名'] = range(1, len(coefficient_dataframe) + 1)
        coefficient_dataframe = coefficient_dataframe.drop('系数绝对值', axis=1)

        # 保存系数分析结果
        coefficient_dataframe.to_excel(
            f'{self.output_directory}/贝叶斯岭回归系数分析表.xlsx',
            index=False
        )

        self.analysis_results['bayesian_model_evaluation'] = evaluation_dataframe
        self.analysis_results['bayesian_coefficient_analysis'] = coefficient_dataframe

        print("贝叶斯岭回归分析完成，系数分析结果已保存")

        return evaluation_dataframe, coefficient_dataframe, bayesian_regression_model, scaled_features, target_vector

    def perform_robust_regression_analysis(self):
        """
        执行鲁棒回归分析

        比较Huber回归和RANSAC回归两种鲁棒回归方法，
        评估它们对异常值的处理能力和模型稳定性

        返回:
            tuple: (模型评估结果, 系数比较结果, Huber模型对象, RANSAC模型对象)
        """
        print("\n=== 鲁棒回归分析方法比较 ===")

        # 定义分析变量
        target_variable = 'Y染色体浓度'
        predictor_variables = ['检测孕周', '孕妇BMI', '年龄', '身高', '体重']

        # 准备完整数据集
        complete_dataset = self.male_fetal_dataset[[target_variable] + predictor_variables].dropna()

        if len(complete_dataset) < 50:
            print("警告: 数据量不足（n<50），鲁棒回归结果可能不可靠")
            return None

        feature_matrix = complete_dataset[predictor_variables]
        target_vector = complete_dataset[target_variable]

        # 特征标准化
        robust_scaler = RobustScaler()
        scaled_features = robust_scaler.fit_transform(feature_matrix)

        # 1. Huber回归模型（对中度异常值鲁棒）
        huber_regression_model = HuberRegressor(
            epsilon=1.35,  # Huber损失函数的转折点参数
            max_iter=1000,  # 最大迭代次数
            alpha=0.0001,  # L2正则化强度
            warm_start=False,  # 不启用热启动
            fit_intercept=True  # 包含截距项
        )

        huber_regression_model.fit(scaled_features, target_vector)
        huber_predictions = huber_regression_model.predict(scaled_features)

        # 2. RANSAC回归模型（对严重异常值鲁棒）
        ransac_regression_model = RANSACRegressor(
            min_samples=0.5,  # 最小内点比例
            residual_threshold=None,  # 自动确定残差阈值
            max_trials=1000,  # 最大抽样次数
            random_state=42  # 随机种子确保可重复性
        )

        ransac_regression_model.fit(scaled_features, target_vector)
        ransac_predictions = ransac_regression_model.predict(scaled_features)

        # 模型性能评估比较
        regression_models_evaluation = []

        # Huber回归性能评估
        huber_r2 = r2_score(target_vector, huber_predictions)
        huber_rmse = np.sqrt(mean_squared_error(target_vector, huber_predictions))
        huber_mae = mean_absolute_error(target_vector, huber_predictions)
        huber_cv_scores = cross_val_score(
            huber_regression_model, scaled_features, target_vector, cv=5, scoring='r2'
        )

        regression_models_evaluation.append({
            '鲁棒回归方法': 'Huber回归',
            '决定系数R²': round(huber_r2, 4),
            '均方根误差RMSE': round(huber_rmse, 6),
            '平均绝对误差MAE': round(huber_mae, 6),
            '交叉验证R²均值': round(huber_cv_scores.mean(), 4),
            '交叉验证R²标准差': round(huber_cv_scores.std(), 4),
            '鲁棒性参数': f"epsilon={huber_regression_model.epsilon}",
            '异常值处理能力': '中等（处理中度异常值）'
        })

        # RANSAC回归性能评估
        ransac_r2 = r2_score(target_vector, ransac_predictions)
        ransac_rmse = np.sqrt(mean_squared_error(target_vector, ransac_predictions))
        ransac_mae = mean_absolute_error(target_vector, ransac_predictions)
        ransac_cv_scores = cross_val_score(
            ransac_regression_model, scaled_features, target_vector, cv=5, scoring='r2'
        )

        # RANSAC内点分析
        inlier_indices = ransac_regression_model.inlier_mask_
        outlier_count = np.sum(~inlier_indices)
        outlier_percentage = outlier_count / len(target_vector) * 100

        regression_models_evaluation.append({
            '鲁棒回归方法': 'RANSAC回归',
            '决定系数R²': round(ransac_r2, 4),
            '均方根误差RMSE': round(ransac_rmse, 6),
            '平均绝对误差MAE': round(ransac_mae, 6),
            '交叉验证R²均值': round(ransac_cv_scores.mean(), 4),
            '交叉验证R²标准差': round(ransac_cv_scores.std(), 4),
            '鲁棒性参数': f"异常值比例={outlier_percentage:.1f}%",
            '异常值处理能力': '强（自动识别并排除异常值）'
        })

        evaluation_dataframe = pd.DataFrame(regression_models_evaluation)

        # 系数一致性比较分析
        coefficient_comparison_results = []

        for index, variable_name in enumerate(predictor_variables):
            huber_coefficient = huber_regression_model.coef_[index]
            ransac_coefficient = ransac_regression_model.estimator_.coef_[index]
            coefficient_difference = abs(huber_coefficient - ransac_coefficient)

            # 评估系数一致性
            if coefficient_difference < 0.001:
                consistency_level = '高度一致'
            elif coefficient_difference < 0.01:
                consistency_level = '中等一致'
            else:
                consistency_level = '差异较大'

            coefficient_comparison_results.append({
                '预测变量': variable_name,
                'Huber回归系数': round(huber_coefficient, 6),
                'RANSAC回归系数': round(ransac_coefficient, 6),
                '系数绝对差异': round(coefficient_difference, 6),
                '系数一致性': consistency_level
            })

        coefficient_comparison_dataframe = pd.DataFrame(coefficient_comparison_results)

        # 保存模型比较结果
        evaluation_dataframe.to_excel(
            f'{self.output_directory}/鲁棒回归模型比较表.xlsx',
            index=False
        )

        self.analysis_results['robust_regression_evaluation'] = evaluation_dataframe
        self.analysis_results['robust_coefficient_comparison'] = coefficient_comparison_dataframe

        print("鲁棒回归分析完成，模型比较结果已保存")

        return evaluation_dataframe, coefficient_comparison_dataframe, huber_regression_model, ransac_regression_model

    def execute_complete_robust_analysis_pipeline(self):
        """
        执行完整的鲁棒贝叶斯分析流程

        包含数据加载、贝叶斯回归分析和鲁棒回归分析三个主要步骤

        返回:
            bool: 分析流程是否成功完成
        """
        print("开始执行鲁棒贝叶斯回归分析流程")
        print("=" * 65)

        # 步骤1: 数据加载与预处理
        if not self.load_and_preprocess_dataset():
            return False

        # 步骤2-3: 执行核心分析
        try:
            self.perform_bayesian_ridge_regression()
            self.perform_robust_regression_analysis()

            print("\n" + "=" * 65)
            print("鲁棒贝叶斯回归分析流程成功完成！")
            print("所有结果文件已保存至目录: {}".format(self.output_directory))
            return True

        except Exception as error:
            print(f"分析流程执行过程中出现错误: {error}")
            return False


def main():
    """
    主函数 - 程序入口点

    创建分析器实例并执行完整的鲁棒贝叶斯回归分析流程
    """
    # 创建鲁棒贝叶斯回归分析器实例
    robust_analyzer = RobustBayesianRegressionAnalyzer()

    # 执行完整分析流程
    robust_analyzer.execute_complete_robust_analysis_pipeline()


if __name__ == "__main__":
    main()