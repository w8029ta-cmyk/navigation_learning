import pandas as pd
import numpy as np
import os
import random
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import warnings
warnings.filterwarnings('ignore')

class MultiFactorRobustNSGA2:
    def __init__(self):
        """初始化多因素鲁棒NSGA-II规划模型"""
        self.data = None
        self.results_dir = "问题三_表"
        self.setup_chinese_font()
        self.create_results_directory()
        
        # NSGA-II算法参数
        self.population_size = 40
        self.generations = 80
        self.crossover_rate = 0.8
        self.mutation_rate = 0.2
        self.tournament_size = 3
        
        # 问题参数
        self.min_groups = 3
        self.max_groups = 6
        self.y_threshold = 0.04
        self.time_bounds = (105, 196)  # 15-28周
        
        # 多因素权重
        self.factor_weights = {
            'bmi': 0.40,      # BMI权重最高
            'age': 0.25,      # 年龄次之
            'height': 0.20,   # 身高
            'weight': 0.15    # 体重
        }
        
        # 不确定性参数
        self.uncertainty_level = 0.1
        self.monte_carlo_samples = 15
        
        # 风险权重
        self.base_weights = {'alpha': 0.5, 'beta': 0.1, 'gamma': 0.3, 'delta': 0.1}
        
        # 加载数据和计算多因素指标
        self.load_and_prepare_data()
    
    def setup_chinese_font(self):
        """设置中文字体"""
        font_paths = [
            'C:/Windows/Fonts/simhei.ttf',
            'C:/Windows/Fonts/msyh.ttc',
            'C:/Windows/Fonts/simsun.ttc'
        ]
        
        self.font_prop = None
        for path in font_paths:
            if os.path.exists(path):
                self.font_prop = FontProperties(fname=path)
                plt.rcParams['font.family'] = self.font_prop.get_name()
                plt.rcParams['axes.unicode_minus'] = False
                break
        
        if self.font_prop is None:
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
            plt.rcParams['axes.unicode_minus'] = False
            self.font_prop = FontProperties()
    
    def create_results_directory(self):
        """创建结果目录"""
        if not os.path.exists(self.results_dir):
            os.makedirs(self.results_dir)
    
    def load_and_prepare_data(self):
        """加载数据并计算多因素综合指标"""
        try:
            # 加载处理后的男胎数据
            self.data = pd.read_excel('男胎数据_处理后.xlsx')
            
            # 筛选有效数据
            valid_mask = (
                (self.data['Y染色体浓度'].notna()) &
                (self.data['BMI_最终'].notna()) &
                (self.data['检测孕周_天数'].notna()) &
                (self.data['年龄'].notna()) &
                (self.data['身高'].notna()) &
                (self.data['体重'].notna())
            )
            
            self.data = self.data[valid_mask].copy()
            
            # 计算多因素综合指标
            self.calculate_multifactor_index()
            
            # 计算达标时间
            self.calculate_achievement_times()
            
            print(f"成功加载数据，有效样本数：{len(self.data)}")
            
        except Exception as e:
            print(f"数据加载失败：{e}")
    
    def calculate_multifactor_index(self):
        """计算多因素综合指标"""
        # 标准化各因素
        scaler = StandardScaler()
        factors = ['BMI_最终', '年龄', '身高', '体重']
        standardized_data = scaler.fit_transform(self.data[factors])
        standardized_df = pd.DataFrame(standardized_data, columns=factors, index=self.data.index)
        
        # 计算各因素影响
        bmi_impact = -standardized_df['BMI_最终']  # BMI负相关
        age_impact = -0.5 * standardized_df['年龄']  # 年龄轻微负相关
        height_impact = 0.3 * standardized_df['身高']  # 身高轻微正相关
        weight_impact = -0.2 * standardized_df['体重']  # 体重负相关
        
        # 计算多因素综合指标
        self.data['多因素综合指标'] = (
            self.factor_weights['bmi'] * bmi_impact +
            self.factor_weights['age'] * age_impact +
            self.factor_weights['height'] * height_impact +
            self.factor_weights['weight'] * weight_impact
        )
        
        # 归一化到[0,1]区间
        mfi_scaler = MinMaxScaler()
        self.data['多因素综合指标_标准化'] = mfi_scaler.fit_transform(
            self.data[['多因素综合指标']]
        ).flatten()
        
        # 提取关键数据
        self.bmi_values = self.data['BMI_最终'].values
        self.y_concentrations = self.data['Y染色体浓度'].values
        self.detection_times = self.data['检测孕周_天数'].values
        self.multifactor_indices = self.data['多因素综合指标_标准化'].values
    
    def calculate_achievement_times(self):
        """计算达标时间"""
        achievement_times = []
        
        for i in range(len(self.data)):
            current_time = self.detection_times[i]
            current_concentration = self.y_concentrations[i]
            mfi = self.multifactor_indices[i]
            
            if current_concentration >= self.y_threshold:
                achievement_time = current_time
            else:
                # 基于多因素指标估算达标时间
                base_growth_rate = 0.0008
                # MFI越高（不利因素越多），达标时间越长
                mfi_factor = 1 + 0.5 * mfi
                adjusted_growth_rate = base_growth_rate / mfi_factor
                
                concentration_gap = self.y_threshold - current_concentration
                days_needed = concentration_gap / adjusted_growth_rate
                achievement_time = current_time + days_needed
            
            achievement_times.append(achievement_time)
        
        self.achievement_times = np.array(achievement_times)
    
    def generate_uncertainty_scenarios(self):
        """生成不确定性场景"""
        scenarios = []
        n_samples = len(self.data)
        
        for _ in range(self.monte_carlo_samples):
            # BMI测量误差
            bmi_noise = np.random.normal(0, self.uncertainty_level * np.std(self.bmi_values), n_samples)
            bmi_perturbed = np.maximum(15, self.bmi_values + bmi_noise)
            
            # Y染色体浓度测量误差
            y_noise = np.random.normal(0, self.uncertainty_level * np.std(self.y_concentrations), n_samples)
            y_perturbed = np.maximum(0, self.y_concentrations + y_noise)
            
            # 多因素指标误差
            mfi_noise = np.random.normal(0, self.uncertainty_level * np.std(self.multifactor_indices), n_samples)
            mfi_perturbed = np.clip(self.multifactor_indices + mfi_noise, 0, 1)
            
            # 时间测量误差
            time_noise = np.random.normal(0, self.uncertainty_level * np.std(self.detection_times), n_samples)
            time_perturbed = np.maximum(105, np.minimum(196, self.detection_times + time_noise))
            
            scenarios.append({
                'bmi': bmi_perturbed,
                'y_concentration': y_perturbed,
                'multifactor_index': mfi_perturbed,
                'detection_time': time_perturbed
            })
        
        return scenarios
    
    class Individual:
        """个体类：表示一个解决方案"""
        def __init__(self, n_groups, n_samples):
            self.n_groups = n_groups
            self.n_samples = n_samples
            
            # 决策变量：BMI分组边界和检测时点
            self.bmi_boundaries = sorted(np.random.uniform(20, 45, max(1, n_groups-1)))
            
            # 生成检测时点，确保各组时点有差异
            self.detection_times = np.random.uniform(105, 196, n_groups)
            # 添加小的随机偏移确保时点不完全相同
            for i in range(1, n_groups):
                while any(abs(self.detection_times[i] - self.detection_times[j]) < 3.0 for j in range(i)):
                    self.detection_times[i] = np.random.uniform(105, 196)
                    # 添加小的随机扰动
                    self.detection_times[i] += np.random.uniform(-2, 2)
                    self.detection_times[i] = np.clip(self.detection_times[i], 105, 196)
            
            # 目标函数值
            self.objectives = None
            self.rank = None
            self.crowding_distance = 0
        
        def assign_groups(self, bmi_values):
            """根据BMI边界分配样本到组"""
            groups = np.zeros(len(bmi_values), dtype=int)
            
            # 确保边界数量正确
            if len(self.bmi_boundaries) != self.n_groups - 1:
                # 重新生成边界
                sorted_bmis = np.sort(bmi_values)
                percentiles = np.linspace(0, 100, self.n_groups + 1)[1:-1]
                self.bmi_boundaries = sorted(np.percentile(sorted_bmis, percentiles))
            
            # 分配样本到组
            for i, bmi in enumerate(bmi_values):
                group_id = 0
                for boundary in self.bmi_boundaries:
                    if bmi <= boundary:
                        break
                    group_id += 1
                groups[i] = min(group_id, self.n_groups - 1)
            
            return groups
    
    def evaluate_individual(self, individual, scenarios):
        """评估个体的目标函数值"""
        all_risks = []
        all_variances = []
        all_imbalances = []
        
        # 对每个不确定性场景进行评估
        for scenario in scenarios:
            # 分配分组
            groups = individual.assign_groups(scenario['bmi'])
            
            # 计算目标1：综合风险
            total_risk = 0
            group_variances = []
            group_sizes = []
            
            for group_id in range(individual.n_groups):
                group_mask = (groups == group_id)
                group_indices = np.where(group_mask)[0]
                
                if len(group_indices) == 0:
                    continue
                
                group_sizes.append(len(group_indices))
                
                if group_id < len(individual.detection_times):
                    detection_time = individual.detection_times[group_id]
                else:
                    detection_time = individual.detection_times[-1]
                
                # 计算该组的风险
                group_risks = []
                group_achievement_times = []
                
                for idx in group_indices:
                    # 基于多因素指标计算风险
                    mfi = scenario['multifactor_index'][idx]
                    
                    # 未达标风险
                    achievement_time = self.achievement_times[idx]
                    if detection_time < achievement_time:
                        p_not_achieved = 0.8 + 0.2 * mfi  # MFI越高风险越大
                    else:
                        p_not_achieved = 0.1 * mfi
                    
                    # 时机风险
                    if detection_time < 84:
                        p_early = 1.0
                        p_mid = 0.0
                        p_late = 0.0
                    elif detection_time <= 189:
                        p_early = 0.0
                        p_mid = 1.0
                        p_late = 0.0
                    else:
                        p_early = 0.0
                        p_mid = 0.0
                        p_late = 1.0
                    
                    # 综合风险
                    risk = (self.base_weights['alpha'] * p_not_achieved + 
                           self.base_weights['beta'] * p_early + 
                           self.base_weights['gamma'] * p_mid + 
                           self.base_weights['delta'] * p_late)
                    
                    group_risks.append(risk)
                    group_achievement_times.append(achievement_time)
                
                if group_risks:
                    avg_group_risk = np.mean(group_risks)
                    total_risk += avg_group_risk * len(group_indices)
                    
                    # 计算该组的时间方差
                    if len(group_achievement_times) > 1:
                        group_variance = np.var(group_achievement_times)
                    else:
                        group_variance = 0
                    group_variances.append(group_variance)
            
            if len(group_sizes) > 0:
                # 目标1：平均风险
                avg_risk = total_risk / sum(group_sizes)
                all_risks.append(avg_risk)
                
                # 目标2：时间方差
                if group_variances:
                    avg_variance = np.mean(group_variances)
                else:
                    avg_variance = 0
                all_variances.append(avg_variance)
                
                # 目标3：组间不平衡
                if len(group_sizes) > 1:
                    ideal_size = sum(group_sizes) / len(group_sizes)
                    imbalance = np.sum([(size - ideal_size) ** 2 for size in group_sizes]) / (sum(group_sizes) ** 2)
                else:
                    imbalance = 0
                all_imbalances.append(imbalance)
        
        # 取所有场景的平均值作为鲁棒性目标值
        if all_risks:
            individual.objectives = [
                np.mean(all_risks),      # 目标1：综合风险最小化
                np.mean(all_variances),  # 目标2：时间方差最小化
                np.mean(all_imbalances)  # 目标3：组间不平衡最小化
            ]
        else:
            individual.objectives = [1.0, 1000.0, 1.0]  # 惩罚值
        
        return individual.objectives
    
    def dominates(self, ind1, ind2):
        """判断ind1是否支配ind2"""
        better_in_any = False
        for i in range(len(ind1.objectives)):
            if ind1.objectives[i] > ind2.objectives[i]:
                return False
            elif ind1.objectives[i] < ind2.objectives[i]:
                better_in_any = True
        return better_in_any
    
    def fast_non_dominated_sort(self, population):
        """快速非支配排序"""
        fronts = [[]]
        n = [0] * len(population)  # 支配个体的数量
        s = [[] for _ in range(len(population))]  # 被支配的个体集合
        
        for i in range(len(population)):
            for j in range(len(population)):
                if i != j:
                    if self.dominates(population[i], population[j]):
                        s[i].append(j)
                    elif self.dominates(population[j], population[i]):
                        n[i] += 1
            
            if n[i] == 0:
                population[i].rank = 0
                fronts[0].append(i)
        
        i = 0
        while len(fronts[i]) > 0:
            next_front = []
            for p in fronts[i]:
                for q in s[p]:
                    n[q] -= 1
                    if n[q] == 0:
                        population[q].rank = i + 1
                        next_front.append(q)
            
            i += 1
            fronts.append(next_front)
        
        return fronts[:-1]  # 移除最后一个空前沿
    
    def calculate_crowding_distance(self, population, front):
        """计算拥挤距离"""
        if len(front) <= 2:
            for i in front:
                population[i].crowding_distance = float('inf')
            return
        
        # 初始化拥挤距离
        for i in front:
            population[i].crowding_distance = 0
        
        # 对每个目标函数
        for obj_idx in range(len(population[0].objectives)):
            # 按目标函数值排序
            front.sort(key=lambda x: population[x].objectives[obj_idx])
            
            # 边界点设置为无穷大
            population[front[0]].crowding_distance = float('inf')
            population[front[-1]].crowding_distance = float('inf')
            
            # 计算目标函数的范围
            obj_min = population[front[0]].objectives[obj_idx]
            obj_max = population[front[-1]].objectives[obj_idx]
            obj_range = obj_max - obj_min
            
            if obj_range == 0:
                continue
            
            # 计算中间点的拥挤距离
            for i in range(1, len(front) - 1):
                if population[front[i]].crowding_distance != float('inf'):
                    distance = (population[front[i + 1]].objectives[obj_idx] - 
                               population[front[i - 1]].objectives[obj_idx]) / obj_range
                    population[front[i]].crowding_distance += distance
    
    def tournament_selection(self, population):
        """锦标赛选择"""
        tournament = random.sample(population, min(self.tournament_size, len(population)))
        
        # 选择最好的个体
        best = tournament[0]
        for individual in tournament[1:]:
            if individual.rank is None:
                individual.rank = float('inf')
            if best.rank is None:
                best.rank = float('inf')
                
            if (individual.rank < best.rank or 
                (individual.rank == best.rank and individual.crowding_distance > best.crowding_distance)):
                best = individual
        
        return best
    
    def crossover(self, parent1, parent2):
        """交叉操作"""
        if random.random() > self.crossover_rate:
            return parent1, parent2
        
        child1 = self.Individual(parent1.n_groups, parent1.n_samples)
        child2 = self.Individual(parent2.n_groups, parent2.n_samples)
        
        # BMI边界交叉
        if len(parent1.bmi_boundaries) == len(parent2.bmi_boundaries):
            crossover_point = random.randint(0, len(parent1.bmi_boundaries))
            child1.bmi_boundaries = sorted(parent1.bmi_boundaries[:crossover_point] + 
                                         parent2.bmi_boundaries[crossover_point:])
            child2.bmi_boundaries = sorted(parent2.bmi_boundaries[:crossover_point] + 
                                         parent1.bmi_boundaries[crossover_point:])
        else:
            child1.bmi_boundaries = parent1.bmi_boundaries.copy()
            child2.bmi_boundaries = parent2.bmi_boundaries.copy()
        
        # 检测时点交叉
        if len(parent1.detection_times) == len(parent2.detection_times):
            crossover_point = random.randint(0, len(parent1.detection_times))
            child1.detection_times = np.concatenate([
                parent1.detection_times[:crossover_point],
                parent2.detection_times[crossover_point:]
            ])
            child2.detection_times = np.concatenate([
                parent2.detection_times[:crossover_point],
                parent1.detection_times[crossover_point:]
            ])
        else:
            child1.detection_times = parent1.detection_times.copy()
            child2.detection_times = parent2.detection_times.copy()
        
        return child1, child2
    
    def mutate(self, individual):
        """变异操作"""
        # BMI边界变异
        if random.random() < 0.5 and individual.bmi_boundaries:
            idx = random.randint(0, len(individual.bmi_boundaries) - 1)
            individual.bmi_boundaries[idx] += random.gauss(0, 2)
            individual.bmi_boundaries[idx] = max(20, min(45, individual.bmi_boundaries[idx]))
            individual.bmi_boundaries = sorted(individual.bmi_boundaries)
        
        # 检测时点变异
        if random.random() < 0.5:
            idx = random.randint(0, len(individual.detection_times) - 1)
            original_time = individual.detection_times[idx]
            individual.detection_times[idx] += random.gauss(0, 8)
            individual.detection_times[idx] = max(105, min(196, individual.detection_times[idx]))
            
            # 检查是否与其他时点过于接近
            other_times = [individual.detection_times[j] for j in range(len(individual.detection_times)) if j != idx]
            if any(abs(individual.detection_times[idx] - other_time) < 2.0 for other_time in other_times):
                individual.detection_times[idx] = original_time + random.uniform(-4, 4)
                individual.detection_times[idx] = max(105, min(196, individual.detection_times[idx]))
        
        return individual
    
    def run_nsga2_optimization(self):
        """运行NSGA-II优化算法"""
        print("开始多因素鲁棒NSGA-II优化...")
        
        # 生成不确定性场景
        scenarios = self.generate_uncertainty_scenarios()
        
        # 初始化种群
        population = []
        for _ in range(self.population_size):
            n_groups = random.randint(self.min_groups, self.max_groups)
            individual = self.Individual(n_groups, len(self.data))
            self.evaluate_individual(individual, scenarios)
            population.append(individual)
        
        # 进化历史记录
        evolution_history = []
        
        # 进化循环
        for generation in range(self.generations):
            # 生成子代
            offspring = []
            for _ in range(self.population_size // 2):
                parent1 = self.tournament_selection(population)
                parent2 = self.tournament_selection(population)
                
                child1, child2 = self.crossover(parent1, parent2)
                child1 = self.mutate(child1)
                child2 = self.mutate(child2)
                
                self.evaluate_individual(child1, scenarios)
                self.evaluate_individual(child2, scenarios)
                
                offspring.extend([child1, child2])
            
            # 合并父代和子代
            combined_population = population + offspring
            
            # 非支配排序
            fronts = self.fast_non_dominated_sort(combined_population)
            
            # 环境选择
            new_population = []
            for front in fronts:
                if len(new_population) + len(front) <= self.population_size:
                    # 计算拥挤距离
                    self.calculate_crowding_distance(combined_population, front)
                    new_population.extend([combined_population[i] for i in front])
                else:
                    # 需要从当前前沿中选择部分个体
                    self.calculate_crowding_distance(combined_population, front)
                    remaining_slots = self.population_size - len(new_population)
                    
                    # 按拥挤距离排序
                    front_individuals = [(combined_population[i], i) for i in front]
                    front_individuals.sort(key=lambda x: x[0].crowding_distance, reverse=True)
                    
                    selected = front_individuals[:remaining_slots]
                    new_population.extend([ind for ind, _ in selected])
                    break
            
            population = new_population
            
            # 记录进化历史
            if generation % 10 == 0:
                best_objectives = [min(ind.objectives[i] for ind in population) 
                                 for i in range(3)]
                evolution_history.append({
                    'generation': generation,
                    'best_risk': best_objectives[0],
                    'best_variance': best_objectives[1],
                    'best_imbalance': best_objectives[2]
                })
                
                print(f"第{generation}代: 风险={best_objectives[0]:.4f}, "
                      f"方差={best_objectives[1]:.2f}, 不平衡={best_objectives[2]:.4f}")
        
        # 获取最终的帕累托前沿
        fronts = self.fast_non_dominated_sort(population)
        pareto_front = [population[i] for i in fronts[0]]
        
        print(f"优化完成！获得{len(pareto_front)}个帕累托最优解")
        
        return pareto_front, evolution_history
    
    def extract_solutions_data(self, pareto_solutions):
        """提取解决方案数据"""
        solutions_data = []
        detailed_results = []
        
        for i, solution in enumerate(pareto_solutions):
            # 分配分组
            groups = solution.assign_groups(self.bmi_values)
            
            # 计算各组详细信息
            group_info = []
            actual_group_count = 0
            
            for group_id in range(solution.n_groups):
                group_mask = (groups == group_id)
                group_indices = np.where(group_mask)[0]
                
                if len(group_indices) > 0:
                    actual_group_count += 1
                    group_data = self.data.iloc[group_indices]
                    
                    if group_id < len(solution.detection_times):
                        detection_time = solution.detection_times[group_id]
                    else:
                        detection_time = solution.detection_times[-1]
                    
                    # 计算达标率
                    group_achievement_times = self.achievement_times[group_indices]
                    achievement_rate = np.mean(group_achievement_times <= detection_time)
                    
                    # 计算平均风险
                    group_risks = []
                    for idx in group_indices:
                        mfi = self.multifactor_indices[idx]
                        achievement_time = self.achievement_times[idx]
                        
                        if detection_time < achievement_time:
                            p_not_achieved = 0.8 + 0.2 * mfi
                        else:
                            p_not_achieved = 0.1 * mfi
                        
                        if detection_time < 84:
                            p_early, p_mid, p_late = 1.0, 0.0, 0.0
                        elif detection_time <= 189:
                            p_early, p_mid, p_late = 0.0, 1.0, 0.0
                        else:
                            p_early, p_mid, p_late = 0.0, 0.0, 1.0
                        
                        risk = (self.base_weights['alpha'] * p_not_achieved + 
                               self.base_weights['beta'] * p_early + 
                               self.base_weights['gamma'] * p_mid + 
                               self.base_weights['delta'] * p_late)
                        group_risks.append(risk)
                    
                    group_info.append({
                        '组别': f'组{actual_group_count}',
                        'BMI区间': f"[{group_data['BMI_最终'].min():.1f}, {group_data['BMI_最终'].max():.1f}]",
                        '样本数': len(group_indices),
                        '平均BMI': group_data['BMI_最终'].mean(),
                        '平均年龄': group_data['年龄'].mean(),
                        '平均身高': group_data['身高'].mean(),
                        '平均体重': group_data['体重'].mean(),
                        '多因素指标': group_data['多因素综合指标_标准化'].mean(),
                        '检测时点_天': detection_time - 49-70,
                        '检测时点_周': detection_time / 7 - 7-10,
                        '达标率': achievement_rate,
                        '平均风险': np.mean(group_risks)
                    })
            
            # 添加到详细结果
            for group in group_info:
                detailed_results.append({
                    '解编号': i + 1,
                    '分组数': actual_group_count,
                    '总体风险': solution.objectives[0],
                    '时间方差': solution.objectives[1],
                    '组间不平衡': solution.objectives[2],
                    **group
                })
            
            # 添加到解决方案汇总
            solutions_data.append({
                '解编号': i + 1,
                '分组数': actual_group_count,
                '综合风险': solution.objectives[0],
                '时间方差': solution.objectives[1],
                '组间不平衡': solution.objectives[2],
                'BMI边界': str([f"{b:.2f}" for b in solution.bmi_boundaries]),
                '检测时点': str([f"{t:.1f}" for t in solution.detection_times])
            })
        
        return solutions_data, detailed_results
    
    def save_results(self, pareto_solutions, evolution_history):
        """保存结果"""
        print("保存优化结果...")
        
        # 提取解决方案数据
        solutions_data, detailed_results = self.extract_solutions_data(pareto_solutions)
        
        # 保存帕累托最优解汇总
        solutions_df = pd.DataFrame(solutions_data)
        solutions_df.to_excel(f'{self.results_dir}/问题三NSGA2帕累托最优解汇总.xlsx')

        # 保存详细分组结果
        detailed_df = pd.DataFrame(detailed_results)
        detailed_df.to_excel(f'{self.results_dir}/问题三NSGA2详细分组结果.xlsx')
        
        # 保存进化历史
        evolution_df = pd.DataFrame(evolution_history)
        evolution_df.to_excel(f'{self.results_dir}/问题三NSGA2进化历史.xlsx')
        
        # 创建最优解汇总表
        summary_data = []
        for sol_data in solutions_data:
            # 找到对应的详细结果
            sol_details = [d for d in detailed_results if d['解编号'] == sol_data['解编号']]
            
            group_summary = []
            for detail in sol_details:
                group_summary.append(f"{detail['组别']}: BMI{detail['BMI区间']}, "
                                   f"{detail['检测时点_周']:.1f}周, "
                                   f"达标率{detail['达标率']:.3f}")
            
            summary_data.append({
                '解编号': sol_data['解编号'],
                '分组方案': '; '.join(group_summary),
                '综合风险': f"{sol_data['综合风险']:.4f}",
                '时间方差': f"{sol_data['时间方差']:.2f}",
                '组间不平衡': f"{sol_data['组间不平衡']:.4f}",
                '方案特点': self.classify_solution(sol_data)
            })
        
        summary_df = pd.DataFrame(summary_data)
        summary_df.to_excel(f'{self.results_dir}/问题三NSGA2最优解汇总表.xlsx')
        
        print("结果保存完成！")
        
        return solutions_df, detailed_df, summary_df
    
    def classify_solution(self, solution):
        """分类解决方案特点"""
        risk = solution['综合风险']
        variance = solution['时间方差']
        imbalance = solution['组间不平衡']
        
        if risk < 0.15 and imbalance < 0.1:
            return "风险低-均衡好"
        elif risk < 0.15:
            return "风险低"
        elif imbalance < 0.1:
            return "均衡好"
        elif variance < 500:
            return "方差小"
        else:
            return "综合方案"

def main():
    """主函数"""
    print("="*60)
    print("问题三：多因素鲁棒NSGA-II多目标规划模型")
    print("三目标：综合风险最小化 + 时间方差最小化 + 组间不平衡最小化")
    print("="*60)
    
    try:
        # 创建优化器
        optimizer = MultiFactorRobustNSGA2()
        
        # 运行NSGA-II优化
        pareto_solutions, evolution_history = optimizer.run_nsga2_optimization()
        
        # 保存结果
        solutions_df, detailed_df, summary_df = optimizer.save_results(pareto_solutions, evolution_history)
        
        # 输出最佳解的详细信息
        best_risk_solution = min(pareto_solutions, key=lambda x: x.objectives[0])
        print(f"\n风险最小解：")
        print(f"  分组数：{best_risk_solution.n_groups}")
        print(f"  综合风险：{best_risk_solution.objectives[0]:.4f}")
        print(f"  时间方差：{best_risk_solution.objectives[1]:.2f}")
        print(f"  组间不平衡：{best_risk_solution.objectives[2]:.4f}")
        
        print(f"\n结果已保存到 {optimizer.results_dir} 目录")
        print("生成的文件包括：")
        print("- 问题三NSGA2帕累托最优解汇总.")
        print("- 问题三NSGA2详细分组结果.")
        print("- 问题三NSGA2最优解汇总表.")
        print("- 问题三NSGA2进化历史.")
        
    except Exception as e:
        print(f"程序运行出错：{e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()







