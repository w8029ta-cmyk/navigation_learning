import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
import os
import warnings
warnings.filterwarnings('ignore')

class Problem3Plotter:
    def __init__(self):
        """初始化"""
        self.results_dir = "问题三_图"
        self.data_dir = "问题三_表"
        
        # 设置中文字体和风格
        self.setup_chinese_font()
        self.setup__style()

        # 加载数据
        self.load_data()
    
    def setup_chinese_font(self):
        """设置中文字体"""
        font_paths = [
            'C:/Windows/Fonts/simhei.ttf',  # 黑体
            'C:/Windows/Fonts/msyh.ttc',    # 微软雅黑
            'C:/Windows/Fonts/simsun.ttc'   # 宋体
        ]
        
        self.font_prop = None
        for path in font_paths:
            if os.path.exists(path):
                self.font_prop = FontProperties(fname=path)
                plt.rcParams['font.family'] = self.font_prop.get_name()
                plt.rcParams['axes.unicode_minus'] = False
                print(f"成功加载字体：{path}")
                break
        
        if self.font_prop is None:
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
            plt.rcParams['axes.unicode_minus'] = False
            self.font_prop = FontProperties()
            print("使用系统默认中文字体")
    
    def setup__style(self):
        """设置风格"""
        plt.rcParams.update({
            'figure.dpi': 300,
            'savefig.dpi': 300,
            'font.size': 13,
            'axes.linewidth': 1.2,
            'axes.labelsize': 13,
            'axes.titlesize': 13,
            'xtick.labelsize': 13,
            'ytick.labelsize': 13,
            'legend.fontsize': 13,
            'figure.figsize': (8, 6),
            'axes.grid': True,
            'grid.alpha': 0.3,
            'grid.linestyle': '--',
            'axes.spines.top': False,
            'axes.spines.right': False
        })

    def load_data(self):
        """加载数据"""
        try:
            # 加载NSGA-II结果数据
            self.pareto_solutions = pd.read_excel(f'{self.data_dir}/问题三NSGA2帕累托最优解汇总.xlsx')
            self.detailed_results = pd.read_excel(f'{self.data_dir}/问题三NSGA2详细分组结果.xlsx')
            self.evolution_history = pd.read_excel(f'{self.data_dir}/问题三NSGA2进化历史.xlsx')
            
            # 加载单目标结果数据
            self.single_obj_results = pd.read_excel(f'{self.data_dir}/问题三多因素最终结果.xlsx')
            self.correlation_analysis = pd.read_excel(f'{self.data_dir}/多因素相关性分析.xlsx')

            # 加载原始数据
            self.raw_data = pd.read_excel('男胎数据_处理后.xlsx')
            
            print("数据加载完成")
            
        except Exception as e:
            print(f"数据加载失败：{e}")
    
    def plot_multifactor_bmi_hexbin(self):
        """多因素指标与BMI关系蜂窝图"""
        plt.figure(figsize=(8, 6))
        
        # 计算多因素综合指标（简化版）
        bmi_values = self.raw_data['BMI_最终'].dropna()
        age_values = self.raw_data['年龄'].dropna()
        
        # 简单的多因素指标计算
        multifactor_index = 0.6 * (bmi_values - bmi_values.mean()) / bmi_values.std() + \
                           0.4 * (age_values[:len(bmi_values)] - age_values.mean()) / age_values.std()
        
        # 创建蜂窝图
        hb = plt.hexbin(bmi_values, multifactor_index, 
                       gridsize=25, 
                       cmap='plasma',
                       alpha=0.8,
                       edgecolors='white',
                       linewidths=0.2)
        
        # 添加颜色条
        cb = plt.colorbar(hb, shrink=0.8)
        cb.set_label('样本密度', fontproperties=self.font_prop, fontsize=13)
        
        plt.xlabel('BMI指数', fontproperties=self.font_prop, fontsize=13)
        plt.ylabel('多因素综合指标', fontproperties=self.font_prop, fontsize=13)
        plt.title('BMI与多因素综合指标关系密度分布', fontproperties=self.font_prop, fontsize=13)
        
        plt.tight_layout()
        plt.savefig(f'{self.results_dir}/BMI与多因素指标蜂窝图.png',
                   dpi=300, bbox_inches='tight')
        plt.close()
        print("BMI与多因素指标蜂窝图 - 已保存")

    def plot_evolution_convergence(self):
        """NSGA-II算法收敛历史"""
        plt.figure(figsize=(8, 6))
        
        generations = self.evolution_history['generation']
        colors = [np.random.rand(3, ) for _ in range(3)]
        
        # 绘制三个目标的收敛曲线
        plt.plot(generations, self.evolution_history['best_risk'], 
                'o-', color=colors[0], linewidth=2.5, markersize=6, 
                label='综合风险', markeredgecolor='white', markeredgewidth=1)
        
        # 为了可视化，将方差和不平衡标准化
        normalized_variance = self.evolution_history['best_variance'] / self.evolution_history['best_variance'].max()
        normalized_imbalance = self.evolution_history['best_imbalance'] / self.evolution_history['best_imbalance'].max()
        
        plt.plot(generations, normalized_variance, 
                's-', color=colors[1], linewidth=2.5, markersize=6, 
                label='时间方差（标准化）', markeredgecolor='white', markeredgewidth=1)
        
        plt.plot(generations, normalized_imbalance, 
                '^-', color=colors[2], linewidth=2.5, markersize=6, 
                label='组间不平衡（标准化）', markeredgecolor='white', markeredgewidth=1)
        
        plt.xlabel('迭代代数', fontproperties=self.font_prop, fontsize=13)
        plt.ylabel('标准化目标函数值', fontproperties=self.font_prop, fontsize=13)
        plt.title('NSGA-II算法收敛历史', fontproperties=self.font_prop, fontsize=13)
        plt.legend(prop=self.font_prop, fontsize=12)
        
        plt.tight_layout()
        plt.savefig(f'{self.results_dir}/NSGA2算法收敛历史.png',
                   dpi=300, bbox_inches='tight')
        plt.close()
        print("NSGA-II算法收敛历史 - 已保存")

    def plot_detection_time_optimization(self):
        """检测时点优化结果"""
        plt.figure(figsize=(8, 6))
        
        # 获取最佳解的数据
        best_solution = self.detailed_results[self.detailed_results['解编号'] == 1]
        
        groups = best_solution['组别']
        detection_weeks = best_solution['检测时点_周']
        achievement_rates = best_solution['达标率']
        
        # 创建双轴图
        fig, ax1 = plt.subplots(figsize=(8, 6))
        
        # 检测时点柱状图
        bars = ax1.bar(groups, detection_weeks, 
                      color=np.random.rand(3, ),
                      alpha=0.8, edgecolor='black', linewidth=1)
        
        ax1.set_xlabel('BMI组别', fontproperties=self.font_prop, fontsize=13)
        ax1.set_ylabel('最佳检测时点（周）', fontproperties=self.font_prop, fontsize=13, 
                      color=np.random.rand(3, ))
        ax1.tick_params(axis='y', labelcolor=np.random.rand(3, ))
        
        # 达标率折线图
        ax2 = ax1.twinx()
        line = ax2.plot(groups, achievement_rates, 
                       'o-', color=np.random.rand(3, ),
                       linewidth=3, markersize=8, 
                       markeredgecolor='white', markeredgewidth=2)
        
        ax2.set_ylabel('预期达标率', fontproperties=self.font_prop, fontsize=13, 
                      color=np.random.rand(3, ))
        ax2.tick_params(axis='y', labelcolor=np.random.rand(3, ))
        ax2.set_ylim(0.7, 1.05)
        
        # 添加数值标签
        for i, (week, rate) in enumerate(zip(detection_weeks, achievement_rates)):
            ax1.text(i, week + 0.5, f'{week:.1f}周', 
                    ha='center', va='bottom', fontproperties=self.font_prop, fontsize=11)
            ax2.text(i, rate + 0.01, f'{rate:.3f}', 
                    ha='center', va='bottom', fontproperties=self.font_prop, fontsize=11)
        
        plt.title('各BMI组最佳检测时点与预期达标率', fontproperties=self.font_prop, fontsize=13)
        plt.tight_layout()
        plt.savefig(f'{self.results_dir}/检测时点优化结果.png',
                   dpi=300, bbox_inches='tight')
        plt.close()
        print("检测时点优化结果 - 已保存")

    def generate_all_plots(self):
        """生成所有图片"""
        print("开始生成问题三风格图片...")
        print("="*50)
        
        try:
            # 生成12类图片
            self.plot_multifactor_bmi_hexbin()
            self.plot_evolution_convergence()
            self.plot_detection_time_optimization()
            
            print("="*50)
            print("问题三风格图片生成完成！")
            print(f"所有图片已保存到：{self.results_dir}")
            
        except Exception as e:
            print(f"图片生成过程中出现错误：{e}")
            import traceback
            traceback.print_exc()

def main():
    """主函数"""
    plotter = Problem3Plotter()
    plotter.generate_all_plots()

if __name__ == "__main__":
    main()
