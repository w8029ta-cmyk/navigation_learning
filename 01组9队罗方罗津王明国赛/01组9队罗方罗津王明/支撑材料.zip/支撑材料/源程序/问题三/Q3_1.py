import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
import os
import warnings
from scipy.optimize import differential_evolution
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler, MinMaxScaler
warnings.filterwarnings('ignore')

class MultiFactorNIPTPlanner:
    def __init__(self):
        """初始化多因素NIPT规划器"""
        self.results_dir = "问题三_表"
        self.setup_chinese_font()
        self.create_results_directory()
        
        # 模型参数
        self.min_groups = 3
        self.max_groups = 6
        self.min_group_size = 80
        self.y_threshold = 0.04
        
        # 时间边界（15-28周）
        self.time_bounds = (105, 196)  # 天数
        
        # 多因素权重（基于临床重要性）
        self.factor_weights = {
            'bmi': 0.40,      # BMI权重最高
            'age': 0.25,      # 年龄次之
            'height': 0.20,   # 身高
            'weight': 0.15    # 体重（部分影响已包含在BMI中）
        }
        
        # 风险权重
        self.risk_weights = {
            'unachieved': 0.5,  # 未达标风险
            'timing': 0.3,      # 时机风险
            'detection': 0.2    # 检测风险
        }
        
        # 误差水平（简化）
        self.error_levels = [0.0, 0.1, 0.2]
        
        # 加载数据
        self.load_data()
    
    def setup_chinese_font(self):
        """设置中文字体"""
        font_paths = [
            'C:/Windows/Fonts/simhei.ttf',
            'C:/Windows/Fonts/msyh.ttc',
            'C:/Windows/Fonts/simsun.ttc'
        ]
        
        self.font_prop = None
        for path in font_paths:
            if os.path.exists(path):
                self.font_prop = FontProperties(fname=path)
                plt.rcParams['font.family'] = self.font_prop.get_name()
                plt.rcParams['axes.unicode_minus'] = False
                break
        
        if self.font_prop is None:
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
            plt.rcParams['axes.unicode_minus'] = False
            self.font_prop = FontProperties()
    
    def create_results_directory(self):
        """创建结果目录"""
        if not os.path.exists(self.results_dir):
            os.makedirs(self.results_dir)
    
    def load_data(self):
        """加载和预处理数据"""
        try:
            # 加载处理后的男胎数据
            self.data = pd.read_excel('男胎数据_处理后.xlsx')
            
            # 筛选有效数据
            valid_mask = (
                (self.data['Y染色体浓度'].notna()) &
                (self.data['BMI_最终'].notna()) &
                (self.data['检测孕周_天数'].notna()) &
                (self.data['年龄'].notna()) &
                (self.data['身高'].notna()) &
                (self.data['体重'].notna())
            )
            
            self.data = self.data[valid_mask].copy()
            
            print(f"成功加载数据，有效样本数：{len(self.data)}")
            
        except Exception as e:
            print(f"数据加载失败：{e}")
    
    def calculate_multifactor_index(self):
        """计算多因素综合指标"""
        print("计算多因素综合指标...")
        
        # 1. 数据标准化
        scaler = StandardScaler()
        factors = ['BMI_最终', '年龄', '身高', '体重']
        
        # 标准化各因素
        standardized_data = scaler.fit_transform(self.data[factors])
        standardized_df = pd.DataFrame(standardized_data, columns=factors, index=self.data.index)
        
        # 2. 计算各因素的影响方向和强度
        # BMI影响：BMI越高，Y染色体浓度越低（负相关）
        bmi_impact = -standardized_df['BMI_最终']  # 负号表示负相关
        
        # 年龄影响：年龄越大，Y染色体浓度可能略低（轻微负相关）
        age_impact = -0.5 * standardized_df['年龄']
        
        # 身高影响：身高对Y染色体浓度的影响相对较小
        height_impact = 0.3 * standardized_df['身高']
        
        # 体重影响：体重增加可能降低浓度（但部分效应已包含在BMI中）
        weight_impact = -0.2 * standardized_df['体重']
        
        # 3. 计算多因素综合指标（MFI: Multi-Factor Index）
        self.data['多因素综合指标'] = (
            self.factor_weights['bmi'] * bmi_impact +
            self.factor_weights['age'] * age_impact +
            self.factor_weights['height'] * height_impact +
            self.factor_weights['weight'] * weight_impact
        )
        
        # 4. 归一化到[0,1]区间，便于解释
        mfi_scaler = MinMaxScaler()
        self.data['多因素综合指标_标准化'] = mfi_scaler.fit_transform(
            self.data[['多因素综合指标']]
        ).flatten()
        
        # 5. 计算各因素相关性
        correlation_analysis = self.analyze_factor_correlations()
        
        print(f"多因素综合指标计算完成")
        print(f"指标范围：{self.data['多因素综合指标'].min():.3f} 到 {self.data['多因素综合指标'].max():.3f}")
        print(f"与Y染色体浓度相关性：{self.data['多因素综合指标'].corr(self.data['Y染色体浓度']):.4f}")
        
        return correlation_analysis
    
    def analyze_factor_correlations(self):
        """分析各因素与Y染色体浓度的相关性"""
        factors = ['BMI_最终', '年龄', '身高', '体重', '多因素综合指标']
        correlations = {}
        
        for factor in factors:
            corr_pearson = self.data[factor].corr(self.data['Y染色体浓度'])
            corr_spearman = self.data[factor].corr(self.data['Y染色体浓度'], method='spearman')
            
            correlations[factor] = {
                'pearson': corr_pearson,
                'spearman': corr_spearman
            }
        
        # 保存相关性分析结果
        corr_data = []
        for factor, corrs in correlations.items():
            corr_data.append({
                '因素': factor,
                'Pearson相关系数': corrs['pearson'],
                'Spearman相关系数': corrs['spearman'],
                '相关强度': self.interpret_correlation(abs(corrs['pearson']))
            })
        
        corr_df = pd.DataFrame(corr_data)
        corr_df.to_excel(f'{self.results_dir}/多因素相关性分析.xlsx')
        
        return correlations
    
    def interpret_correlation(self, abs_corr):
        """解释相关性强度"""
        if abs_corr >= 0.7:
            return "强相关"
        elif abs_corr >= 0.5:
            return "中等相关"
        elif abs_corr >= 0.3:
            return "弱相关"
        else:
            return "极弱相关"
    
    def predict_y_concentration_multifactor(self, row, time_days, noise_std=0.0):
        """基于多因素指标预测Y染色体浓度"""
        # 基础浓度模型（时间效应）
        base_conc = 0.015 + 0.0008 * (time_days - 100)
        
        # 多因素影响
        mfi = row['多因素综合指标_标准化']
        
        # MFI越高（不利因素越多），浓度越低
        multifactor_effect = -0.015 * mfi
        
        # 时间的非线性效应
        time_effect = 0.000001 * (time_days - 150) ** 2
        
        # 综合预测
        predicted_conc = base_conc + multifactor_effect - time_effect
        
        # 添加噪声
        if noise_std > 0:
            predicted_conc += np.random.normal(0, noise_std)
        
        return max(0.005, predicted_conc)
    
    def calculate_achievement_time_multifactor(self, row, threshold=0.04):
        """计算基于多因素的达标时间"""
        # 使用二分查找
        left, right = 70, 350
        tolerance = 0.5
        
        for _ in range(30):
            mid = (left + right) / 2
            conc = self.predict_y_concentration_multifactor(row, mid)
            
            if abs(conc - threshold) < 0.001:
                return mid
            elif conc < threshold:
                left = mid
            else:
                right = mid
            
            if right - left < tolerance:
                break
        
        return (left + right) / 2
    
    def calculate_comprehensive_risk_multifactor(self, row, detection_time, noise_std=0.0):
        """计算基于多因素的综合风险"""
        # 计算达标时间
        achievement_time = self.calculate_achievement_time_multifactor(row)
        
        # 1. 未达标风险
        if detection_time < achievement_time:
            time_diff = achievement_time - detection_time
            unachieved_risk = min(1.0, 0.8 + 0.2 * (time_diff / 30))  # 基于时间差
        else:
            # 已达标，但仍有小概率风险
            time_buffer = detection_time - achievement_time
            unachieved_risk = max(0.05, 0.3 * np.exp(-time_buffer / 20))
        
        # 2. 时机风险
        if detection_time < 84:  # 12周前（早期）
            timing_risk = 0.9
        elif detection_time <= 189:  # 13-27周（中期）
            timing_risk = 0.1
        else:  # 28周后（晚期）
            timing_risk = 0.8
        
        # 3. 检测风险（基于多因素指标）
        mfi = row['多因素综合指标_标准化']
        base_detection_risk = 0.1 + 0.2 * mfi  # MFI越高，检测越困难
        
        # 时间相关的检测风险
        if detection_time < 105 or detection_time > 196:  # 超出合理范围
            time_detection_risk = 0.3
        else:
            time_detection_risk = 0.0
        
        detection_risk = min(1.0, base_detection_risk + time_detection_risk)
        
        # 4. 综合风险
        total_risk = (
            self.risk_weights['unachieved'] * unachieved_risk +
            self.risk_weights['timing'] * timing_risk +
            self.risk_weights['detection'] * detection_risk
        )
        
        return total_risk, unachieved_risk, timing_risk, detection_risk
    
    def optimal_multifactor_grouping(self, n_groups):
        """基于多因素指标的最优分组"""
        # 使用BMI和多因素综合指标进行二维聚类
        features = self.data[['BMI_最终', '多因素综合指标_标准化']].values
        
        # K-means聚类
        kmeans = KMeans(n_clusters=n_groups, random_state=42, n_init=10)
        cluster_labels = kmeans.fit_predict(features)
        
        # 按BMI均值排序分组
        group_info = []
        for i in range(n_groups):
            group_mask = (cluster_labels == i)
            group_data = self.data[group_mask]
            
            if len(group_data) >= self.min_group_size:
                group_info.append({
                    'group_id': i,
                    'data_indices': group_data.index.tolist(),
                    'sample_count': len(group_data),
                    'avg_bmi': group_data['BMI_最终'].mean(),
                    'bmi_range': [group_data['BMI_最终'].min(), group_data['BMI_最终'].max()],
                    'avg_mfi': group_data['多因素综合指标_标准化'].mean(),
                    'avg_age': group_data['年龄'].mean(),
                    'avg_height': group_data['身高'].mean(),
                    'avg_weight': group_data['体重'].mean()
                })
        
        # 按平均BMI排序
        group_info.sort(key=lambda x: x['avg_bmi'])
        
        return group_info
    
    def optimize_group_detection_times(self, group_info):
        """优化各组的检测时点"""
        optimal_times = []
        
        for group in group_info:
            group_data = self.data.loc[group['data_indices']]
            
            def objective_function(time_point):
                """单个组的目标函数"""
                total_risk = 0
                for _, row in group_data.iterrows():
                    risk, _, _, _ = self.calculate_comprehensive_risk_multifactor(row, time_point[0])
                    total_risk += risk
                
                return total_risk / len(group_data)
            
            # 约束检测时点在合理范围内
            bounds = [self.time_bounds]
            
            # 使用差分进化算法优化（简化）
            result = differential_evolution(
                objective_function, 
                bounds, 
                seed=42, 
                maxiter=20,
                popsize=8
            )
            
            optimal_time = result.x[0]
            optimal_risk = result.fun
            
            # 添加小的随机扰动避免时点完全相同
            if len(optimal_times) > 0:
                previous_times = [t['optimal_time'] for t in optimal_times]
                while any(abs(optimal_time - prev_time) < 2.0 for prev_time in previous_times):
                    optimal_time += np.random.uniform(-3, 3)
                    optimal_time = np.clip(optimal_time, self.time_bounds[0], self.time_bounds[1])
            
            optimal_times.append({
                'group_id': group['group_id'],
                'optimal_time': optimal_time,
                'optimal_weeks': optimal_time / 7,
                'average_risk': optimal_risk
            })
        
        return optimal_times
    
    def evaluate_multifactor_solution(self, n_groups):
        """评估多因素解决方案"""
        # 分组
        group_info = self.optimal_multifactor_grouping(n_groups)
        
        if len(group_info) < n_groups:
            return None  # 分组失败
        
        # 优化时点
        optimal_times = self.optimize_group_detection_times(group_info)
        
        # 评估解决方案
        detailed_results = []
        total_risk = 0
        total_samples = 0
        
        for i, (group, time_info) in enumerate(zip(group_info, optimal_times)):
            group_data = self.data.loc[group['data_indices']]
            
            # 计算该组的详细指标
            group_risks = []
            achievement_rates = []
            
            for _, row in group_data.iterrows():
                risk, unachieved, timing, detection = self.calculate_comprehensive_risk_multifactor(
                    row, time_info['optimal_time']
                )
                group_risks.append(risk)
                
                # 达标率
                achievement_time = self.calculate_achievement_time_multifactor(row)
                is_achieved = time_info['optimal_time'] >= achievement_time
                achievement_rates.append(1.0 if is_achieved else 0.0)
            
            avg_risk = np.mean(group_risks)
            achievement_rate = np.mean(achievement_rates)
            
            detailed_results.append({
                '组别': f'组{i+1}',
                'BMI区间': f"[{group['bmi_range'][0]:.1f}, {group['bmi_range'][1]:.1f}]",
                '样本数': group['sample_count'],
                '平均BMI': group['avg_bmi'],
                '平均年龄': group['avg_age'],
                '平均身高': group['avg_height'],
                '平均体重': group['avg_weight'],
                '多因素指标': group['avg_mfi'],
                '最佳检测时点_天': time_info['optimal_time'],
                '最佳检测时点_周': time_info['optimal_weeks'],
                '平均风险': avg_risk,
                '达标率': achievement_rate
            })
            
            total_risk += avg_risk * group['sample_count']
            total_samples += group['sample_count']
        
        overall_risk = total_risk / total_samples
        
        return {
            'n_groups': len(group_info),
            'overall_risk': overall_risk,
            'detailed_results': detailed_results
        }
    
    def analyze_error_impact(self, best_solution):
        """分析检测误差对结果的影响"""
        print("分析检测误差影响...")
        
        error_impact_results = []
        
        for error_level in self.error_levels:
            print(f"  分析{error_level*100:.0f}%误差水平...")
            
            # 蒙特卡洛采样（简化）
            n_samples = 10
            risk_samples = []
            achievement_samples = []
            
            for _ in range(n_samples):
                total_risk = 0
                total_achievement = 0
                total_count = 0
                
                for group_result in best_solution['detailed_results']:
                    group_name = group_result['组别']
                    detection_time = group_result['最佳检测时点_天']
                    
                    # 获取该组的数据
                    group_data = self.data[
                        (self.data['BMI_最终'] >= float(group_result['BMI区间'].split('[')[1].split(',')[0])) &
                        (self.data['BMI_最终'] <= float(group_result['BMI区间'].split(',')[1].split(']')[0]))
                    ]
                    
                    if len(group_data) == 0:
                        continue
                    
                    group_risks = []
                    group_achievements = []
                    
                    for _, row in group_data.iterrows():
                        # 添加误差
                        noisy_row = row.copy()
                        
                        # BMI误差
                        bmi_noise = np.random.normal(0, error_level * row['BMI_最终'])
                        noisy_row['BMI_最终'] = max(15, row['BMI_最终'] + bmi_noise)
                        
                        # 年龄误差
                        age_noise = np.random.normal(0, error_level * row['年龄'])
                        noisy_row['年龄'] = max(18, row['年龄'] + age_noise)
                        
                        # 身高误差
                        height_noise = np.random.normal(0, error_level * row['身高'])
                        noisy_row['身高'] = max(140, row['身高'] + height_noise)
                        
                        # 体重误差
                        weight_noise = np.random.normal(0, error_level * row['体重'])
                        noisy_row['体重'] = max(40, row['体重'] + weight_noise)
                        
                        # 重新计算多因素指标
                        mfi_noise = np.random.normal(0, error_level * row['多因素综合指标_标准化'])
                        noisy_row['多因素综合指标_标准化'] = np.clip(
                            row['多因素综合指标_标准化'] + mfi_noise, 0, 1
                        )
                        
                        # 计算风险
                        risk, _, _, _ = self.calculate_comprehensive_risk_multifactor(
                            noisy_row, detection_time, noise_std=error_level * 0.005
                        )
                        group_risks.append(risk)
                        
                        # 计算达标率
                        achievement_time = self.calculate_achievement_time_multifactor(noisy_row)
                        is_achieved = detection_time >= achievement_time
                        group_achievements.append(1.0 if is_achieved else 0.0)
                    
                    total_risk += np.mean(group_risks) * len(group_data)
                    total_achievement += np.mean(group_achievements) * len(group_data)
                    total_count += len(group_data)
                
                if total_count > 0:
                    risk_samples.append(total_risk / total_count)
                    achievement_samples.append(total_achievement / total_count)
            
            # 计算统计指标
            if risk_samples:
                error_impact_results.append({
                    '误差水平': f'{error_level*100:.0f}%',
                    '平均风险': np.mean(risk_samples),
                    '风险标准差': np.std(risk_samples),
                    '平均达标率': np.mean(achievement_samples),
                    '达标率标准差': np.std(achievement_samples),
                    '风险增长率': (np.mean(risk_samples) - error_impact_results[0]['平均风险']) / error_impact_results[0]['平均风险'] if error_impact_results else 0.0
                })
        
        # 保存误差影响分析结果
        error_df = pd.DataFrame(error_impact_results)
        error_df.to_excel(f'{self.results_dir}/问题三误差影响分析.xlsx')
        
        return error_df
    
    def run_multifactor_optimization(self):
        """运行多因素优化"""
        print("="*60)
        print("问题三：多因素综合NIPT时点规划模型")
        print("="*60)
        
        # 计算多因素综合指标
        correlation_analysis = self.calculate_multifactor_index()
        
        # 寻找最优分组方案
        best_solution = None
        best_risk = float('inf')
        all_solutions = []
        
        print("\n评估不同分组方案...")
        for n_groups in range(self.min_groups, self.max_groups + 1):
            print(f"评估{n_groups}组方案...")
            
            solution = self.evaluate_multifactor_solution(n_groups)
            
            if solution is not None:
                all_solutions.append(solution)
                print(f"  总体风险: {solution['overall_risk']:.4f}")
                
                if solution['overall_risk'] < best_risk:
                    best_risk = solution['overall_risk']
                    best_solution = solution
        
        if best_solution is None:
            print("未找到有效的解决方案！")
            return None
        
        print(f"\n最优方案：{best_solution['n_groups']}组，总体风险：{best_solution['overall_risk']:.4f}")
        
        # 分析检测误差影响
        error_impact = self.analyze_error_impact(best_solution)
        
        # 保存结果
        self.save_multifactor_results(best_solution, all_solutions, error_impact)
        
        return best_solution, all_solutions, error_impact
    
    def save_multifactor_results(self, best_solution, all_solutions, error_impact):
        """保存多因素优化结果"""
        print("\n保存优化结果...")
        
        # 保存最佳解决方案详细结果
        best_df = pd.DataFrame(best_solution['detailed_results'])
        best_df.to_excel(f'{self.results_dir}/问题三最佳多因素分组结果.xlsx')
        

        summary_data = []
        for group in best_solution['detailed_results']:
            summary_data.append({
                '组别': group['组别'],
                'BMI区间': group['BMI区间'],
                '样本数': group['样本数'],
                '平均BMI': f"{group['平均BMI']:.2f}",
                '平均年龄': f"{group['平均年龄']:.1f}岁",
                '平均身高': f"{group['平均身高']:.1f}cm",
                '平均体重': f"{group['平均体重']:.1f}kg",
                '多因素指标': f"{group['多因素指标']:.3f}",
                '最佳NIPT时点': f"{group['最佳检测时点_天']:.1f}天 ({group['最佳检测时点_周']:.1f}周)",
                '预期达标率': f"{group['达标率']:.3f}",
                '平均风险': f"{group['平均风险']:.4f}",
                '风险等级': self.classify_risk(group['平均风险'])
            })
        
        summary_df = pd.DataFrame(summary_data)
        summary_df.to_excel(f'{self.results_dir}/问题三多因素最终结果.xlsx')
        
        print("结果保存完成！")
        
        return best_df, summary_df
    
    def classify_risk(self, risk_value):
        """风险等级分类"""
        if risk_value <= 0.2:
            return "低风险"
        elif risk_value <= 0.4:
            return "中等风险"
        else:
            return "高风险"
    
    def display_results(self, best_solution, error_impact):
        """显示结果"""
        print(f"\n" + "="*60)
        print("问题三多因素优化结果")
        print("="*60)
        print(f"分组数：{best_solution['n_groups']}")
        print(f"总体平均风险：{best_solution['overall_risk']:.4f}")
        
        print(f"\n各组详细信息：")
        for group in best_solution['detailed_results']:
            print(f"\n{group['组别']}：")
            print(f"  BMI区间：{group['BMI区间']}")
            print(f"  样本数：{group['样本数']}")
            print(f"  平均BMI：{group['平均BMI']:.2f}")
            print(f"  平均年龄：{group['平均年龄']:.1f}岁")
            print(f"  平均身高：{group['平均身高']:.1f}cm")
            print(f"  平均体重：{group['平均体重']:.1f}kg")
            print(f"  多因素指标：{group['多因素指标']:.3f}")
            print(f"  最佳检测时点：{group['最佳检测时点_天']:.1f}天 ({group['最佳检测时点_周']:.1f}周)")
            print(f"  预期达标率：{group['达标率']:.3f}")
            print(f"  平均风险：{group['平均风险']:.4f}")
        
        print(f"\n检测误差影响分析：")
        print(f"  无误差风险：{error_impact.iloc[0]['平均风险']:.4f}")
        print(f"  20%误差风险：{error_impact.iloc[-1]['平均风险']:.4f}")
        print(f"  风险增长率：{error_impact.iloc[-1]['风险增长率']:.2%}")
        
        print(f"\n结果文件已保存到 {self.results_dir} 目录")

def main():
    """主函数"""
    try:
        print("初始化多因素NIPT规划器...")
        planner = MultiFactorNIPTPlanner()
        
        print("开始运行多因素优化...")
        # 运行多因素优化
        results = planner.run_multifactor_optimization()
        
        if results is not None:
            best_solution, all_solutions, error_impact = results
            planner.display_results(best_solution, error_impact)
        else:
            print("优化失败，请检查数据和参数设置。")
    
    except Exception as e:
        print(f"程序运行出错：{e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
